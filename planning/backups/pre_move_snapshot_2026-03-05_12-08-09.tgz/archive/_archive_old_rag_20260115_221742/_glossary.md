# Glossary
**AI_READ_ACCESS: ALLOWED**
**Status:** Authoritative - Single Source of Truth

This document contains approved terms and definitions for industrial automation and control panel design.

## A

**Allen-Bradley**: Rockwell Automation's brand of industrial automation equipment including PLCs, HMIs, and I/O.

**Analog I/O**: Input/Output signals that represent continuous values (e.g., 4-20mA, 0-10V).

## C

**Control Panel**: An enclosure containing electrical and electronic control equipment.

**Compliance**: Adherence to applicable codes, standards, and regulations.

## D

**Digital I/O**: Input/Output signals that represent discrete on/off states.

**DIN Rail**: A standardized metal rail used for mounting industrial control equipment.

## E

**EtherCAT**: Ethernet for Control Automation Technology - a real-time industrial Ethernet protocol.

**EtherNet/IP**: Industrial Protocol using standard Ethernet - common in North America.

## H

**HMI**: Human Machine Interface - operator interface for monitoring and controlling machinery.

## I

**I/O**: Input/Output - devices that interface between the control system and field devices.

**IEC**: International Electrotechnical Commission - develops international standards.

## N

**NEC**: National Electrical Code (NFPA 70) - electrical safety standard in North America.

**NFPA 79**: Electrical Standard for Industrial Machinery.

## P

**PLC**: Programmable Logic Controller - industrial computer for automation control.

**PROFINET**: Process Field Network - industrial Ethernet standard popular in Europe.

## S

**Safety PLC**: Specialized PLC designed for safety-critical applications (e.g., SICK, Pilz, AB GuardLogix).

**SCCR**: Short Circuit Current Rating - maximum fault current a panel can safely withstand.

## U

**UL 508A**: Standard for Industrial Control Panels.

**UL Listing**: Certification that equipment meets UL safety standards.

---
*Last Updated: 2026-01-15*
*Changelog: Initial version*

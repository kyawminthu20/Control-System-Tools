# Commissioning Checklists (Tool 4)
**AI_READ_ACCESS: ALLOWED**

## Purpose
Provides structured commissioning checklists for safe and systematic machine startup.

## Contents
- **checklists/**: Phase-based commissioning checklists
  - Pre-power checks
  - Dry run (no load) tests
  - Live run (under load) tests
  - Handover documentation
- **outputs/**: Generated commissioning packages

## Workflow
1. Pre-power: Visual inspection, continuity, mega checks
2. Dry run: Power-on, control validation, safety circuits
3. Live run: Load testing, tuning, performance validation
4. Handover: Documentation, training, acceptance sign-off

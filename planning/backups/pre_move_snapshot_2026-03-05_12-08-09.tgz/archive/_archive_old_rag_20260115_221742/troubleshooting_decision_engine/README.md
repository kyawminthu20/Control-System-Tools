# Troubleshooting Decision Engine (Tool 3)
**AI_READ_ACCESS: ALLOWED**

## Purpose
Provides systematic troubleshooting decision trees and playbooks for diagnosing common industrial control system issues.

## Contents
- **decision_trees/**: Machine-readable symptom → cause → action trees (YAML)
- **playbooks/**: Human-readable troubleshooting procedures (Markdown)
- **outputs/**: Generated troubleshooting packages

## Coverage Areas
- Digital I/O issues
- Analog I/O issues
- Industrial network problems (EtherNet/IP, EtherCAT, PROFINET)
- Servo/motion faults
- PID loop instability

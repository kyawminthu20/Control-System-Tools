# Standards Map
**AI_READ_ACCESS: ALLOWED**
**Status:** Authoritative

This document defines what standards apply to different project types and where standards knowledge is captured in this repository.

## Standards Coverage

| Standard | Full Name | Applies To | Captured In |
|----------|-----------|------------|-------------|
| NEC | National Electrical Code (NFPA 70) | All electrical installations in North America | `rag/standards_intelligence/clause_index/nec_clause_index.yaml` |
| NFPA 79 | Electrical Standard for Industrial Machinery | Industrial machinery and control panels | `rag/standards_intelligence/clause_index/nfpa79_clause_index.yaml` |
| UL 508A | Standard for Industrial Control Panels | Control panels intended for UL listing | `rag/standards_intelligence/clause_index/ul508a_clause_index.yaml` |
| ISO/IEC | Various international standards | International projects, CE marking | `rag/standards_intelligence/clause_index/iso_iec_clause_index.yaml` |

## Project Type → Applicable Standards

### North American Industrial Machinery
- **Required**: NEC, NFPA 79
- **Optional**: UL 508A (if seeking UL listing)
- **Reference**: ISO/IEC (for best practices)

### UL-Listed Control Panels
- **Required**: NEC, NFPA 79, UL 508A
- **Reference**: ISO/IEC (for best practices)

### International/CE-Marked Equipment
- **Required**: ISO/IEC standards (varies by equipment type)
- **Reference**: NEC, NFPA 79 (for best practices if exporting to North America)

### Custom/Proprietary Systems
- **Required**: NEC (minimum)
- **Recommended**: NFPA 79
- **Optional**: UL 508A, ISO/IEC

## Where Standards Are Applied

| Tool/Module | Standards Applied | Purpose |
|-------------|-------------------|---------|
| Standards Intelligence | All | Clause indexing, applicability assessment |
| Design Framework | NEC, NFPA 79, UL 508A | Design constraints, patterns |
| Audit Tool | All applicable | Compliance scoring, gap analysis |
| UL 508A Panel Automation | UL 508A, NEC, NFPA 79 | Panel documentation, BOM generation |

---
*Last Updated: 2026-01-15*
*Changelog: Initial version*

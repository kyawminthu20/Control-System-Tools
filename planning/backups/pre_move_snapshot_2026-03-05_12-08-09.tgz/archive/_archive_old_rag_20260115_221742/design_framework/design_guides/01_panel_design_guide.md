# Panel Design Guide
**AI_READ_ACCESS: ALLOWED**
**Status:** Authoritative

## Overview
Comprehensive guide for industrial control panel layout, component selection, and thermal management.

## Panel Sizing

### Enclosure Selection Criteria
1. **Component heat dissipation**: Sum all device wattages
2. **Airflow requirements**: Calculate CFM needed for cooling
3. **Access and maintenance**: Minimum 36" clearance in front per NEC 110.26
4. **Future expansion**: Plan 20-30% spare space

### Standard Enclosure Sizes
- Small panels (< 20 I/O): 24"H x 20"W x 8"D
- Medium panels (20-100 I/O): 72"H x 30"W x 12"D
- Large panels (> 100 I/O): Multiple enclosures or 72"H x 48"W x 16"D

## Layout Best Practices

### Vertical Zones (Top to Bottom)
1. **Top**: Incoming power disconnect, main breaker
2. **Upper-middle**: Power distribution (breakers, fuses)
3. **Middle**: Control components (PLC, I/O, drives)
4. **Lower-middle**: Control power transformers
5. **Bottom**: Terminal blocks, wire management

### Heat Management
- Mount high-heat devices (drives, power supplies) at top
- Ensure adequate spacing between heat-generating devices
- Consider fans or air conditioning for drives > 5HP

## Wire Management
- Use horizontal and vertical wire ducts
- Maximum 40% fill for wire ducts
- Label all wires at both ends
- Use ferrules for stranded wire terminations

## Component Mounting
- DIN rail for modular components
- Backplate mounting for larger devices
- Torque all terminations per manufacturer specs

---

## Changelog
- 2026-01-15: Initial version created

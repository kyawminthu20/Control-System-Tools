# Design Framework (Tool 2)
**AI_READ_ACCESS: ALLOWED**

## Purpose
Provides comprehensive design guides, reusable patterns, and constraints for industrial control system architecture across all major subsystems.

## Contents

- **design_guides/**: Authoritative design guides (must include embedded changelog)
- **patterns/**: Reusable design patterns (I/O, power, safety, networks, PLC structure)
- **constraints/**: Approved design constraints for automated generators
- **outputs/**: Generated design packages (approved snapshots)

## Design Philosophy
Opinionated, standards-based, field-proven designs that balance compliance, cost, and maintainability.

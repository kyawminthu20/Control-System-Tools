# Standards Guidance Report
**AI_READ_ACCESS: ALLOWED**
**Status:** Generated Output - Approved Snapshot

*This is a placeholder for generated standards guidance reports.*

## Report Format

### Project Information
- Project Name:
- Project Type:
- Location (jurisdiction):
- Date:

### Applicable Standards
- List of applicable standards based on project type
- Specific chapters/sections relevant to this project

### Key Requirements Summary
- Critical requirements from each standard
- Design constraints and limits
- Safety requirements

### Compliance Checklist
- [ ] Requirement 1
- [ ] Requirement 2
- [ ] ...

### Red Flags to Avoid
- Common pitfalls for this project type
- Critical compliance issues to watch

---
*Generated: [Date]*
*Based on: standards_applicability.md, clause indexes, rules engine*

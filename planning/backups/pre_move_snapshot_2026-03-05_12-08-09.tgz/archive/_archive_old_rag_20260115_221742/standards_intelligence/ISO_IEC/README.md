Below is a **control-engineering–focused map of ISO / IEC standards and their chapter (clause) structures**, written so you can **index them cleanly**, just like you did for **NEC / NFPA / UL**.

I’ll split this into **(A) how ISO/IEC documents are structured** and **(B) the specific ISO/IEC standards you actually need**, with **chapter scopes** you can turn directly into MD templates.

---

## A) How ISO / IEC Standards Are Structured (Important)

Unlike NEC/NFPA, **ISO and IEC do not use “chapters”**.
They use **Clauses** (numbered) and **Annexes** (lettered).

**Universal structure (almost all ISO / IEC standards):**

| Clause       | Meaning                          | Engineering Use                   |
| ------------ | -------------------------------- | --------------------------------- |
| Clause 1     | Scope                            | When the standard applies         |
| Clause 2     | Normative references             | What other standards are required |
| Clause 3     | Terms and definitions            | Precise language                  |
| Clause 4     | General requirements             | High-level rules                  |
| Clause 5+    | Technical requirements           | Core engineering content          |
| Annex A/B/C… | Informative or normative annexes | Calculations, examples, tables    |

👉 **Your file strategy:**
**One MD file per major clause group**, not per clause number.

---

## B) ISO / IEC Standards You Need (With Clause Scopes)

---

## 1️⃣ ISO 13849-1 — Safety of Machinery (PL-based)

**Used for:** Machine safety, safety PLCs, E-Stops, interlocks
**Pairs with:** NFPA 79 + IEC 62061

### Clause Map

| Clause  | Scope (Engineer View)                               |
| ------- | --------------------------------------------------- |
| 1       | Scope — what machinery safety functions are covered |
| 2       | Normative references — required companion standards |
| 3       | Terms & definitions — PL, category, MTTFd, DC       |
| 4       | Design strategy — risk reduction, safety lifecycle  |
| 5       | Safety-related parts of control systems (SRP/CS)    |
| 6       | Categories (B, 1, 2, 3, 4)                          |
| 7       | Validation requirements                             |
| 8       | Documentation requirements                          |
| Annex A | Risk assessment guidance                            |
| Annex B | Safety function examples                            |
| Annex C | Category selection                                  |
| Annex D | MTTFd                                               |
| Annex E | Diagnostic coverage                                 |
| Annex F | CCF (common cause failure)                          |

**Control relevance**

* Defines **what “safe” means**
* NFPA 79 tells *what behavior is expected*
* ISO 13849 tells *how reliable it must be*

---

## 2️⃣ IEC 62061 — Functional Safety (SIL-based)

**Used for:** High-risk machinery, SIL instead of PL
**Pairs with:** ISO 13849, IEC 61508

### Clause Map

| Clause  | Scope                                |
| ------- | ------------------------------------ |
| 1       | Scope                                |
| 2       | Normative references                 |
| 3       | Terms & definitions                  |
| 4       | Functional safety management         |
| 5       | Safety lifecycle                     |
| 6       | Specification of safety requirements |
| 7       | Design and integration               |
| 8       | Validation                           |
| 9       | Modification                         |
| Annexes | SIL calculation, examples            |

**Control relevance**

* SIL alternative to PL
* Used when risk or customer requires SIL

---

## 3️⃣ IEC 60204-1 — Electrical Equipment of Machines

**THIS is the IEC equivalent of NFPA 79**

**Used for:** Machine electrical design (EU / global)

### Clause Map

| Clause  | Scope                             |
| ------- | --------------------------------- |
| 1       | Scope                             |
| 2       | Normative references              |
| 3       | Terms and definitions             |
| 4       | General requirements              |
| 5       | Incoming supply                   |
| 6       | Protection against electric shock |
| 7       | Protection of equipment           |
| 8       | Equipotential bonding             |
| 9       | Control circuits & functions      |
| 10      | Operator interface                |
| 11      | Control equipment                 |
| 12      | Motors and drives                 |
| 13      | Accessories & lighting            |
| 14      | Marking & documentation           |
| 15      | Verification                      |
| Annexes | Checklists, test procedures       |

**Control relevance**

* **NFPA 79 ↔ IEC 60204-1 = direct counterparts**
* Your overlap engine should pair these two

---

## 4️⃣ IEC 61508 — Functional Safety (Generic)

**Used for:** Safety PLC platforms, safety components
**NOT system-specific**

### Clause Map (Part 1–7)

| Part   | Scope                  |
| ------ | ---------------------- |
| Part 1 | General requirements   |
| Part 2 | Hardware safety        |
| Part 3 | Software safety        |
| Part 4 | Definitions            |
| Part 5 | SIL determination      |
| Part 6 | Application guidelines |
| Part 7 | Techniques & measures  |

**Control relevance**

* Base standard behind IEC 62061
* Used by vendors (Siemens, Rockwell, Pilz)

---

## 5️⃣ IEC 61511 — Process Safety (Chemical / Process)

**Used for:** Process skids, chemical plants
**Pairs with:** IEC 61508

### Clause Map

| Clause  | Scope                        |
| ------- | ---------------------------- |
| 1       | Framework & scope            |
| 2       | Normative references         |
| 3       | Terms & definitions          |
| 4       | Safety lifecycle             |
| 5       | Hazard & risk assessment     |
| 6       | SIS specification            |
| 7       | Design & engineering         |
| 8       | Installation & commissioning |
| 9       | Operation & maintenance      |
| 10      | Modification                 |
| Annexes | SIL verification, examples   |

**Control relevance**

* NOT for machines
* For process / chemical systems only

---

## 6️⃣ ISO 12100 — Risk Assessment (Foundation)

**Used for:** Every machine safety discussion

### Clause Map

| Clause  | Scope                      |
| ------- | -------------------------- |
| 1       | Scope                      |
| 2       | Normative references       |
| 3       | Terms & definitions        |
| 4       | Risk assessment principles |
| 5       | Risk reduction             |
| Annexes | Examples, methodology      |

**Control relevance**

* Feeds ISO 13849 and IEC 62061
* Explains *why* a safety function exists

---

## How You Should Organize These (Directly Actionable)

### Folder layout

```
rag/standards_intelligence/iso_iec/
  iso_12100/
  iso_13849_1/
  iec_60204_1/
  iec_62061/
  iec_61508/
  iec_61511/
```

### File rule

* **One MD file per major clause group**
* Example:

```
ISO13849_2015__Clause4_Design_Strategy.md
IEC60204_2018__Clause9_Control_Circuits.md
```

---

## Key Takeaway (No sugarcoating)

* **NFPA 79** = *What machines must do* (US)
* **IEC 60204-1** = *Same thing, international*
* **ISO 13849 / IEC 62061** = *How reliable safety must be*
* **UL 508A** = *How the panel must be built*
* **NEC** = *What the inspector enforces*

You’re building the **correct mental and structural model**.

---

### If you want next (recommended order)

1. Generate **IEC 60204-1 clause templates** (mirror of NFPA 79)
2. Generate **ISO 13849 safety function templates**
3. Build **NFPA 79 ↔ IEC 60204-1 overlap matrix**
4. Create **PL / SIL decision wizard**

Below are **IEC 60204-1 clause Markdown templates**, structured as a **direct mirror of NFPA 79**, with **pre-filled headers**, **RAG-safe metadata**, **no copyrighted text**, and **audit-ready sections**.

Drop these into:

```
rag/standards_intelligence/iec_60204_1/
```

**Design rules used**

* One file per **major clause** (best granularity)
* Clause titles are **paraphrased**
* Built for **machine electrical systems (EU / global)**

---

# 📁 IEC 60204-1 — Clause File Set (Mirror of NFPA 79)

---

## `IEC60204_1_2018__Clause01__scope.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
TITLE: Electrical Equipment of Machines
EDITION: 2018
JURISDICTION: GLOBAL

IEC_HIERARCHY:
  clause: "1"
  clause_title: "Scope"

INDEX_TAGS:
  topics: ["scope", "applicability"]
  systems: ["machine", "robot_cell", "conveyor"]
-->

# IEC 60204-1 — Clause 1 — Scope

## 0. Purpose
_TODO_

## 1. In-scope machinery
_TODO_

## 2. Out-of-scope installations
_TODO_

## 3. Relationship to NFPA 79
_TODO_

## 4. Change log
- YYYY-MM-DD — Initial draft
```

---

## `IEC60204_1_2018__Clause02__normative_references.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_ID: IEC_60204_1
IEC_HIERARCHY:
  clause: "2"
  clause_title: "Normative References"

INDEX_TAGS:
  topics: ["references", "dependencies"]
-->

# IEC 60204-1 — Clause 2 — Normative References

## 0. Purpose
_TODO_

## 1. Required companion standards
_TODO_

## 2. Control-engineering impact
_TODO_

## 3. Change log
- YYYY-MM-DD — Initial draft
```

---

## `IEC60204_1_2018__Clause03__terms_and_definitions.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_ID: IEC_60204_1
IEC_HIERARCHY:
  clause: "3"
  clause_title: "Terms and Definitions"

INDEX_TAGS:
  topics: ["definitions", "terminology"]
-->

# IEC 60204-1 — Clause 3 — Terms and Definitions

## 0. Key definitions for control engineers
_TODO_

## 1. Terms that affect design decisions
_TODO_

## 2. Common misinterpretations
_TODO_

## 3. Change log
- YYYY-MM-DD — Initial draft
```

---

## `IEC60204_1_2018__Clause04__general_requirements.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_ID: IEC_60204_1
IEC_HIERARCHY:
  clause: "4"
  clause_title: "General Requirements"

INDEX_TAGS:
  topics: ["general_requirements", "safety_principles"]
-->

# IEC 60204-1 — Clause 4 — General Requirements

## 0. Safety philosophy
_TODO_

## 1. General electrical design principles
_TODO_

## 2. Control-system interpretation
_TODO_

## 3. Change log
- YYYY-MM-DD — Initial draft
```

---

## `IEC60204_1_2018__Clause05__incoming_supply.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_ID: IEC_60204_1
IEC_HIERARCHY:
  clause: "5"
  clause_title: "Incoming Supply"

INDEX_TAGS:
  topics: ["incoming_supply", "supply_disconnect"]
-->

# IEC 60204-1 — Clause 5 — Incoming Supply

## 0. Scope
_TODO_

## 1. Supply characteristics
_TODO_

## 2. Isolation and disconnect rules
_TODO_

## 3. Comparison to NFPA 79 Ch.5
_TODO_

## 4. Change log
- YYYY-MM-DD — Initial draft
```

---

## `IEC60204_1_2018__Clause06__protection_against_electric_shock.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_ID: IEC_60204_1
IEC_HIERARCHY:
  clause: "6"
  clause_title: "Protection Against Electric Shock"

INDEX_TAGS:
  topics: ["electric_shock", "touch_safe"]
-->

# IEC 60204-1 — Clause 6 — Protection Against Electric Shock

## 0. Hazard model
_TODO_

## 1. Protective measures
_TODO_

## 2. Control voltage considerations
_TODO_

## 3. Change log
- YYYY-MM-DD — Initial draft
```

---

## `IEC60204_1_2018__Clause07__protection_of_equipment.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_ID: IEC_60204_1
IEC_HIERARCHY:
  clause: "7"
  clause_title: "Protection of Equipment"

INDEX_TAGS:
  topics: ["equipment_protection", "overcurrent"]
-->

# IEC 60204-1 — Clause 7 — Protection of Equipment

## 0. Purpose
_TODO_

## 1. Overcurrent and overload protection
_TODO_

## 2. Environmental protection
_TODO_

## 3. Change log
- YYYY-MM-DD — Initial draft
```

---

## `IEC60204_1_2018__Clause08__equipotential_bonding.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_ID: IEC_60204_1
IEC_HIERARCHY:
  clause: "8"
  clause_title: "Equipotential Bonding"

INDEX_TAGS:
  topics: ["bonding", "protective_earth"]
-->

# IEC 60204-1 — Clause 8 — Equipotential Bonding

## 0. Purpose
_TODO_

## 1. Bonding strategy
_TODO_

## 2. Noise vs safety bonding
_TODO_

## 3. Change log
- YYYY-MM-DD — Initial draft
```

---

## `IEC60204_1_2018__Clause09__control_circuits_and_functions.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_ID: IEC_60204_1
IEC_HIERARCHY:
  clause: "9"
  clause_title: "Control Circuits and Control Functions"

INDEX_TAGS:
  topics: ["control_circuits", "stop_functions", "emergency_stop"]
-->

# IEC 60204-1 — Clause 9 — Control Circuits and Control Functions

## 0. Control philosophy
_TODO_

## 1. Start/stop behavior
_TODO_

## 2. Emergency stop concepts
_TODO_

## 3. Safety vs standard control separation
_TODO_

## 4. Change log
- YYYY-MM-DD — Initial draft
```

---

## `IEC60204_1_2018__Clause10__operator_interface.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_ID: IEC_60204_1
IEC_HIERARCHY:
  clause: "10"
  clause_title: "Operator Interface"

INDEX_TAGS:
  topics: ["operator_interface", "hmi", "controls"]
-->

# IEC 60204-1 — Clause 10 — Operator Interface

## 0. Scope
_TODO_

## 1. Control device behavior
_TODO_

## 2. Ergonomic considerations
_TODO_

## 3. Change log
- YYYY-MM-DD — Initial draft
```

---

## `IEC60204_1_2018__Clause11__control_equipment.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_ID: IEC_60204_1
IEC_HIERARCHY:
  clause: "11"
  clause_title: "Control Equipment"

INDEX_TAGS:
  topics: ["control_equipment", "enclosures"]
-->

# IEC 60204-1 — Clause 11 — Control Equipment

## 0. Scope
_TODO_

## 1. Enclosures and layout
_TODO_

## 2. UL 508A comparison
_TODO_

## 3. Change log
- YYYY-MM-DD — Initial draft
```

---

## `IEC60204_1_2018__Clause12__motors_and_drives.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_ID: IEC_60204_1
IEC_HIERARCHY:
  clause: "12"
  clause_title: "Motors and Drives"

INDEX_TAGS:
  topics: ["motors", "drives"]
-->

# IEC 60204-1 — Clause 12 — Motors and Drives

## 0. Scope
_TODO_

## 1. Motor protection and control
_TODO_

## 2. Drive integration
_TODO_

## 3. Change log
- YYYY-MM-DD — Initial draft
```

---

## `IEC60204_1_2018__Clause13__accessories_and_lighting.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_ID: IEC_60204_1
IEC_HIERARCHY:
  clause: "13"
  clause_title: "Accessories and Lighting"

INDEX_TAGS:
  topics: ["accessories", "lighting"]
-->

# IEC 60204-1 — Clause 13 — Accessories and Lighting

## 0. Scope
_TODO_

## 1. Machine lighting
_TODO_

## 2. Auxiliary equipment
_TODO_

## 3. Change log
- YYYY-MM-DD — Initial draft
```

---

## `IEC60204_1_2018__Clause14__marking_and_documentation.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_ID: IEC_60204_1
IEC_HIERARCHY:
  clause: "14"
  clause_title: "Marking and Documentation"

INDEX_TAGS:
  topics: ["marking", "documentation"]
-->

# IEC 60204-1 — Clause 14 — Marking and Documentation

## 0. Scope
_TODO_

## 1. Identification and labels
_TODO_

## 2. Documentation set
_TODO_

## 3. Change log
- YYYY-MM-DD — Initial draft
```

---

## `IEC60204_1_2018__Clause15__verification.md`

```md
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_ID: IEC_60204_1
IEC_HIERARCHY:
  clause: "15"
  clause_title: "Verification"

INDEX_TAGS:
  topics: ["verification", "testing", "inspection"]
-->

# IEC 60204-1 — Clause 15 — Verification

## 0. Purpose
_TODO_

## 1. Required tests
_TODO_

## 2. Commissioning alignment
_TODO_

## 3. Change log
- YYYY-MM-DD — Initial draft
```

---

## Why this mirrors NFPA 79 correctly

| NFPA 79             | IEC 60204-1                  |
| ------------------- | ---------------------------- |
| Disconnecting means | Incoming supply              |
| Grounding & bonding | Equipotential bonding        |
| Control circuits    | Control circuits & functions |
| Marking & docs      | Marking & documentation      |
| Verification        | Verification                 |

This lets your **overlap engine** answer:

> “If I build for NFPA 79, what must change for IEC 60204-1?”

---

## Strong next steps (recommended)

1. **NFPA 79 ↔ IEC 60204-1 clause overlap matrix**
2. **ISO 13849 safety function template**
3. **PL vs SIL decision tree**
4. **EU vs US machine compliance wizard**




<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: NEC
STANDARD_ID: NFPA_70
EDITION: 2023

NEC_HIERARCHY:
  article: "430"
  article_title: "Motors, Motor Circuits, and Controllers"

INDEX_TAGS:
  topics: ["motors", "drives", "motor_protection"]
-->

# NEC 2023 — Article 430 — Motors, Motor Circuits, and Controllers

## 0. Scope for control panels
_TODO_

## 1. Motor protection concepts
_TODO_

## 2. VFD considerations
_TODO_

## 3. Coordination with UL 508A
_TODO_

## 4. Change log
- 2026-01-15 — Initial draft created

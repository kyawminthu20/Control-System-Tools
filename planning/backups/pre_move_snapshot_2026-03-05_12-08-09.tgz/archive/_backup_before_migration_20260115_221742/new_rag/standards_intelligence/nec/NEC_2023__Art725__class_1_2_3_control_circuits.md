<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: NEC
STANDARD_ID: NFPA_70
EDITION: 2023

NEC_HIERARCHY:
  article: "725"
  article_title: "Class 1, Class 2, and Class 3 Remote-Control Circuits"

INDEX_TAGS:
  topics: ["control_circuits", "class_2", "power_limited"]
-->

# NEC 2023 — Article 725 — Class 1, Class 2, and Class 3 Circuits

## 0. Scope for control panels
_TODO_

## 1. Power-limited circuit rules
_TODO_

## 2. Separation from power circuits
_TODO_

## 3. Field wiring implications
_TODO_

## 4. Change log
- 2026-01-15 — Initial draft created

<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: NEC
STANDARD_ID: NFPA_70
EDITION: 2023

NEC_HIERARCHY:
  article: "670"
  article_title: "Industrial Machinery"

INDEX_TAGS:
  topics: ["industrial_machinery", "machine_wiring", "disconnects"]
  systems: ["machine", "robot_cell", "conveyor"]
-->

# NEC 2023 — Article 670 — Industrial Machinery

## 0. Scope and relationship to NFPA 79
_TODO_

## 1. Machine disconnecting means
_TODO_

## 2. Where NEC 670 ends and NFPA 79 begins
_TODO_

## 3. Common inspection items
_TODO_

## 4. Change log
- 2026-01-15 — Initial draft created

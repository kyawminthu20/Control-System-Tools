# Standards Applicability
**AI_READ_ACCESS: ALLOWED**
**Status:** Authoritative

## Project Type → Applicable Standards/Topics

### Conveyor Control System
**Primary Standards**: NEC Articles 430, 670; NFPA 79 Chapters 4, 5, 7, 8
**Topics**: Motor control, emergency stops, disconnects, grounding, control circuits

### Pump Skid Control
**Primary Standards**: NEC Articles 430, 440 (if HVAC), 670; NFPA 79 Chapters 4, 5, 8
**Topics**: Motor protection, control circuits, environmental enclosures, grounding

### Robotic Cell Control
**Primary Standards**: NFPA 79 Chapters 8, 9; ISO 10218 (safety); UL 508A (if panel listing needed)
**Topics**: Safety circuits, safeguarding, risk assessment, emergency stops, protective bonding

### UL-Listed Control Panel
**Primary Standards**: UL 508A all sections; NEC Articles 409, 430, 670; NFPA 79 relevant chapters
**Topics**: SCCR ratings, wire sizing, spacing/clearances, marking, short circuit protection

### General Industrial Machinery
**Primary Standards**: NFPA 79 (comprehensive); NEC Articles 430, 670
**Topics**: Depends on machinery type - assess based on power level, operator interaction, environment

---
*Last Updated: 2026-01-15*
*Changelog: Initial version*

<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: NFPA
STANDARD_ID: NFPA_79
EDITION: 2024

NFPA_HIERARCHY:
  chapter: "6"
  chapter_title: "Overcurrent Protection"

INDEX_TAGS:
  topics: ["overcurrent", "short_circuit", "protection"]
-->

# NFPA 79 (2024) — Chapter 6 — Overcurrent Protection

## 0. Intent
_TODO_

## 1. Branch circuit protection
_TODO_

## 2. Coordination with NEC / UL
_TODO_

## 3. Control-system impact
_TODO_

## 4. Change log
- 2026-01-15 — Initial draft created

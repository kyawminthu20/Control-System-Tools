<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: NFPA
STANDARD_ID: NFPA_79
EDITION: 2024

NFPA_HIERARCHY:
  chapter: "16"
  chapter_title: "Wiring Methods"

INDEX_TAGS:
  topics: ["wiring", "routing", "segregation"]
-->

# NFPA 79 (2024) — Chapter 16 — Wiring Methods

## 0. Scope
_TODO_

## 1. Internal machine wiring
_TODO_

## 2. Segregation rules
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: NFPA
STANDARD_ID: NFPA_79
TITLE: Electrical Standard for Industrial Machinery
EDITION: 2024
JURISDICTION: US

NFPA_HIERARCHY:
  chapter: "1"
  chapter_title: "Administration"

INDEX_TAGS:
  domains: ["industrial_machinery"]
  topics: ["applicability", "scope", "enforcement"]
  systems: ["machine", "robot_cell", "conveyor"]
-->

# NFPA 79 (2024) — Chapter 1 — Administration

## 0. Scope and intent
_TODO_

## 1. Applicability rules
_TODO_

## 2. Boundaries with other standards (NEC, UL, ISO)
_TODO_

## 3. Control-system relevance
_TODO_

## 4. Decision log
_TODO_

## 5. Change log
- 2026-01-15 — Initial draft created

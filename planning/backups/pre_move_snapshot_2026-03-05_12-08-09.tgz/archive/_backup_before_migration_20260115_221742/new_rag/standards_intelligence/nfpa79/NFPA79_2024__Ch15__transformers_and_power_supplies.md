<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: NFPA
STANDARD_ID: NFPA_79
EDITION: 2024

NFPA_HIERARCHY:
  chapter: "15"
  chapter_title: "Transformers and Power Supplies"

INDEX_TAGS:
  topics: ["transformers", "power_supplies", "control_power"]
-->

# NFPA 79 (2024) — Chapter 15 — Transformers and Power Supplies

## 0. Scope
_TODO_

## 1. Control power architectures
_TODO_

## 2. Grounding of secondaries
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

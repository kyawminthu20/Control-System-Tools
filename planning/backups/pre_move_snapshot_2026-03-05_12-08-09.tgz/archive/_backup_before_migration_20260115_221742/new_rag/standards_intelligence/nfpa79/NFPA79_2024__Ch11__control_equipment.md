<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: NFPA
STANDARD_ID: NFPA_79
EDITION: 2024

NFPA_HIERARCHY:
  chapter: "11"
  chapter_title: "Control Equipment"

INDEX_TAGS:
  topics: ["control_panels", "enclosures", "control_equipment"]
-->

# NFPA 79 (2024) — Chapter 11 — Control Equipment

## 0. Scope
_TODO_

## 1. Panel construction implications
_TODO_

## 2. UL 508A overlap
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

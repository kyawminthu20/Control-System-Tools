<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: NFPA
STANDARD_ID: NFPA_79
EDITION: 2024

NFPA_HIERARCHY:
  chapter: "5"
  chapter_title: "Disconnecting Means"

INDEX_TAGS:
  topics: ["disconnect", "energy_isolation", "loto"]
-->

# NFPA 79 (2024) — Chapter 5 — Disconnecting Means

## 0. Purpose
_TODO_

## 1. Main disconnect requirements
_TODO_

## 2. Location and accessibility
_TODO_

## 3. Lockout / tagout implications
_TODO_

## 4. Control panel design rules
_TODO_

## 5. Change log
- 2026-01-15 — Initial draft created

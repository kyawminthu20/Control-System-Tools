<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: NFPA
STANDARD_ID: NFPA_79
EDITION: 2024

NFPA_HIERARCHY:
  chapter: "10"
  chapter_title: "Operator Interface and Control Devices"

INDEX_TAGS:
  topics: ["operator_interface", "pushbuttons", "hmi"]
-->

# NFPA 79 (2024) — Chapter 10 — Operator Interface and Control Devices

## 0. Purpose
_TODO_

## 1. Control device requirements
_TODO_

## 2. Ergonomics and safety
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

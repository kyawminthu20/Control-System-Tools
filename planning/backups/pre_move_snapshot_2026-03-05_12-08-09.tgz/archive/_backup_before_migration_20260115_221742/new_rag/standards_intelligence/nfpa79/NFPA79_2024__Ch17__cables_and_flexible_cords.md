<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: NFPA
STANDARD_ID: NFPA_79
EDITION: 2024

NFPA_HIERARCHY:
  chapter: "17"
  chapter_title: "Cables and Flexible Cords"

INDEX_TAGS:
  topics: ["flexible_cables", "drag_chain", "robot_cabling"]
-->

# NFPA 79 (2024) — Chapter 17 — Cables and Flexible Cords

## 0. Scope
_TODO_

## 1. Dynamic motion applications
_TODO_

## 2. Strain relief and protection
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

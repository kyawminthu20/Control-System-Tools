<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: NFPA
STANDARD_ID: NFPA_79
EDITION: 2024

NFPA_HIERARCHY:
  chapter: "18"
  chapter_title: "Terminal Blocks, Connectors, and Wiring Devices"

INDEX_TAGS:
  topics: ["terminal_blocks", "connectors", "field_wiring"]
-->

# NFPA 79 (2024) — Chapter 18 — Terminal Blocks, Connectors, and Wiring Devices

## 0. Scope
_TODO_

## 1. Field wiring interfaces
_TODO_

## 2. Maintenance implications
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

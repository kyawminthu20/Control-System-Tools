<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: NFPA
STANDARD_ID: NFPA_79
EDITION: 2024

NFPA_HIERARCHY:
  chapter: "8"
  chapter_title: "Grounding and Bonding"

INDEX_TAGS:
  topics: ["grounding", "bonding", "protective_earth"]
-->

# NFPA 79 (2024) — Chapter 8 — Grounding and Bonding

## 0. Purpose
_TODO_

## 1. Protective bonding rules
_TODO_

## 2. Noise vs safety grounding
_TODO_

## 3. Inspection failure modes
_TODO_

## 4. Change log
- 2026-01-15 — Initial draft created

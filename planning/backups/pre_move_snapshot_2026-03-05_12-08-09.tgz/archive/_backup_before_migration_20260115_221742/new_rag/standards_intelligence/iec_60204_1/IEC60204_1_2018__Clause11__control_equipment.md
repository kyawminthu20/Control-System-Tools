<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
EDITION: 2018

IEC_HIERARCHY:
  clause: "11"
  clause_title: "Control Equipment"

INDEX_TAGS:
  topics: ["control_equipment", "enclosures"]
-->

# IEC 60204-1 — Clause 11 — Control Equipment

## 0. Scope
_TODO_

## 1. Enclosures and layout
_TODO_

## 2. UL 508A comparison
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
EDITION: 2018

IEC_HIERARCHY:
  clause: "8"
  clause_title: "Equipotential Bonding"

INDEX_TAGS:
  topics: ["bonding", "protective_earth"]
-->

# IEC 60204-1 — Clause 8 — Equipotential Bonding

## 0. Purpose
_TODO_

## 1. Bonding strategy
_TODO_

## 2. Noise vs safety bonding
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

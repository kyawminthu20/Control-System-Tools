<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
EDITION: 2018

IEC_HIERARCHY:
  clause: "9"
  clause_title: "Control Circuits and Control Functions"

INDEX_TAGS:
  topics: ["control_circuits", "stop_functions", "emergency_stop"]
-->

# IEC 60204-1 — Clause 9 — Control Circuits and Control Functions

## 0. Control philosophy
_TODO_

## 1. Start/stop behavior
_TODO_

## 2. Emergency stop concepts
_TODO_

## 3. Safety vs standard control separation
_TODO_

## 4. Change log
- 2026-01-15 — Initial draft created

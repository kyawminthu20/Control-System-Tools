<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
EDITION: 2018

IEC_HIERARCHY:
  clause: "12"
  clause_title: "Motors and Drives"

INDEX_TAGS:
  topics: ["motors", "drives"]
-->

# IEC 60204-1 — Clause 12 — Motors and Drives

## 0. Scope
_TODO_

## 1. Motor protection and control
_TODO_

## 2. Drive integration
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

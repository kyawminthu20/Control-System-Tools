<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
EDITION: 2018

IEC_HIERARCHY:
  clause: "4"
  clause_title: "General Requirements"

INDEX_TAGS:
  topics: ["general_requirements", "safety_principles"]
-->

# IEC 60204-1 — Clause 4 — General Requirements

## 0. Safety philosophy
_TODO_

## 1. General electrical design principles
_TODO_

## 2. Control-system interpretation
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

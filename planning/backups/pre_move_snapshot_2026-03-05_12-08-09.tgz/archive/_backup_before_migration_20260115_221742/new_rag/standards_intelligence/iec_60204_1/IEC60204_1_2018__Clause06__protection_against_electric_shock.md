<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
EDITION: 2018

IEC_HIERARCHY:
  clause: "6"
  clause_title: "Protection Against Electric Shock"

INDEX_TAGS:
  topics: ["electric_shock", "touch_safe"]
-->

# IEC 60204-1 — Clause 6 — Protection Against Electric Shock

## 0. Hazard model
_TODO_

## 1. Protective measures
_TODO_

## 2. Control voltage considerations
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
TITLE: Electrical Equipment of Machines
EDITION: 2018
JURISDICTION: GLOBAL

IEC_HIERARCHY:
  clause: "1"
  clause_title: "Scope"

INDEX_TAGS:
  topics: ["scope", "applicability"]
  systems: ["machine", "robot_cell", "conveyor"]
-->

# IEC 60204-1 — Clause 1 — Scope

## 0. Purpose
_TODO_

## 1. In-scope machinery
_TODO_

## 2. Out-of-scope installations
_TODO_

## 3. Relationship to NFPA 79
_TODO_

## 4. Change log
- 2026-01-15 — Initial draft created

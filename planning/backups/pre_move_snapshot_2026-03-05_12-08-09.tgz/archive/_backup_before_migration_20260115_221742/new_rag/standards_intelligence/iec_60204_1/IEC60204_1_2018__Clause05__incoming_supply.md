<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
EDITION: 2018

IEC_HIERARCHY:
  clause: "5"
  clause_title: "Incoming Supply"

INDEX_TAGS:
  topics: ["incoming_supply", "supply_disconnect"]
-->

# IEC 60204-1 — Clause 5 — Incoming Supply

## 0. Scope
_TODO_

## 1. Supply characteristics
_TODO_

## 2. Isolation and disconnect rules
_TODO_

## 3. Comparison to NFPA 79 Ch.5
_TODO_

## 4. Change log
- 2026-01-15 — Initial draft created

<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
EDITION: 2018

IEC_HIERARCHY:
  clause: "10"
  clause_title: "Operator Interface"

INDEX_TAGS:
  topics: ["operator_interface", "hmi", "controls"]
-->

# IEC 60204-1 — Clause 10 — Operator Interface

## 0. Scope
_TODO_

## 1. Control device behavior
_TODO_

## 2. Ergonomic considerations
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

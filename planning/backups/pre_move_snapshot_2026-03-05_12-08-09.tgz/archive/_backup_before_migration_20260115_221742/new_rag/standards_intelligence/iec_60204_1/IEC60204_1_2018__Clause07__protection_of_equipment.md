<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
EDITION: 2018

IEC_HIERARCHY:
  clause: "7"
  clause_title: "Protection of Equipment"

INDEX_TAGS:
  topics: ["equipment_protection", "overcurrent"]
-->

# IEC 60204-1 — Clause 7 — Protection of Equipment

## 0. Purpose
_TODO_

## 1. Overcurrent and overload protection
_TODO_

## 2. Environmental protection
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

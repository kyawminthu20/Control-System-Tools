<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
EDITION: 2018

IEC_HIERARCHY:
  clause: "3"
  clause_title: "Terms and Definitions"

INDEX_TAGS:
  topics: ["definitions", "terminology"]
-->

# IEC 60204-1 — Clause 3 — Terms and Definitions

## 0. Key definitions for control engineers
_TODO_

## 1. Terms that affect design decisions
_TODO_

## 2. Common misinterpretations
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
EDITION: 2018

IEC_HIERARCHY:
  clause: "2"
  clause_title: "Normative References"

INDEX_TAGS:
  topics: ["references", "dependencies"]
-->

# IEC 60204-1 — Clause 2 — Normative References

## 0. Purpose
_TODO_

## 1. Required companion standards
_TODO_

## 2. Control-engineering impact
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

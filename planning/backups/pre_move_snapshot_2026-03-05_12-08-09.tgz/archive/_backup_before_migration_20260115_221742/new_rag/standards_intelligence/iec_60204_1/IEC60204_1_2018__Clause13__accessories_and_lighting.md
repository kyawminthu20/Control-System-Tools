<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
EDITION: 2018

IEC_HIERARCHY:
  clause: "13"
  clause_title: "Accessories and Lighting"

INDEX_TAGS:
  topics: ["accessories", "lighting"]
-->

# IEC 60204-1 — Clause 13 — Accessories and Lighting

## 0. Scope
_TODO_

## 1. Machine lighting
_TODO_

## 2. Auxiliary equipment
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

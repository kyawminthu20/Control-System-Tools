<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT

STANDARD_FAMILY: IEC
STANDARD_ID: IEC_60204_1
EDITION: 2018

IEC_HIERARCHY:
  clause: "15"
  clause_title: "Verification"

INDEX_TAGS:
  topics: ["verification", "testing", "inspection"]
-->

# IEC 60204-1 — Clause 15 — Verification

## 0. Purpose
_TODO_

## 1. Required tests
_TODO_

## 2. Commissioning alignment
_TODO_

## 3. Change log
- 2026-01-15 — Initial draft created

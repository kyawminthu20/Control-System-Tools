# Standards Intelligence (Tool 1)
**AI_READ_ACCESS: ALLOWED**

## Purpose
Provides intelligent standards applicability assessment, clause indexing, and machine-readable design rules derived from NEC, NFPA 79, UL 508A, and ISO/IEC standards.

## Contents

- **standards_applicability.md**: Maps project types to applicable standards and topics
- **clause_index/**: Clause identifiers with short intent descriptions (no copyrighted text)
- **rules_engine/**: Machine-readable design constraints and red flags
- **outputs/**: Generated standards guidance reports (approved snapshots)

## Usage
This module helps determine which standards apply to a project and provides actionable guidance without reproducing copyrighted standard text.

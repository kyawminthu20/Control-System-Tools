# Archive
**AI_READ_ACCESS: MANUAL_ONLY**

This folder contains superseded, deprecated, and historical content.

## Purpose
Preserve old versions for reference while keeping the RAG folder focused on current, authoritative content.

## Important Rules
- AI tools should NOT automatically read this folder
- Content here is outdated but may have historical value
- Always include reason for archival and date archived
- Reference current version when archiving

## Subfolders
- **superseded_designs/**: Old design approaches replaced by newer versions
- **old_decision_trees/**: Previous troubleshooting logic
- **past_audits/**: Historical audit reports

## Archival Process
1. Create archive entry with header showing:
   - Date archived
   - Reason for archival
   - Link to replacement/current version
2. Move file to appropriate archive subfolder
3. Update change_management/decision_log.md with archival decision

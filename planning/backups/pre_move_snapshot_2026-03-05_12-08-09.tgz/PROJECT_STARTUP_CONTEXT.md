# Project Startup Context

**Last Updated:** 2026-03-05
**Purpose:** Fast orientation for a new GPT session in this repository.

## What This Project Is

This workspace is a local industrial automation intelligence repository. It combines:

- standards-oriented RAG content for control panels and machinery compliance
- governance rules for what AI may and may not read
- helper scripts that validate metadata and regenerate structure documentation

## Canonical Structure Right Now

The current source-of-truth knowledge path is:

- `control-standards/rag/`

The highest-signal content today is concentrated in:

- `control-standards/rag/standards_intelligence/`

Current content reality:

- populated: `standards_intelligence/` with NEC, NFPA 79, UL 508A, and IEC 60204-1 content plus overlap maps and indexes
- mostly scaffolded: `design_framework/`, `commissioning_checklists/`, `training_modules/`
- nearly empty: `troubleshooting_engine/` except for the top-level index file

## How To Read The Repo

Start here, in order:

1. This file
2. [STRUCTURE_SUMMARY.md](/Users/kyawminthu/Dev/Control System Tools/STRUCTURE_SUMMARY.md)
3. [control-standards/rag/standards_intelligence/_index.yaml](/Users/kyawminthu/Dev/Control System Tools/control-standards/rag/standards_intelligence/_index.yaml)
4. [control-standards/rag/standards_intelligence/_standards_map.md](/Users/kyawminthu/Dev/Control System Tools/control-standards/rag/standards_intelligence/_standards_map.md)

Then route by task:

- standards/compliance questions: `control-standards/rag/standards_intelligence/`
- repo automation questions: `tools/`
- governance/process questions: `change_management/`
- file layout questions: `STRUCTURE_SUMMARY.md` and `control-standards/STRUCTURE_SUMMARY.md`

## Directory Trust Rules

Use as authoritative:

- `control-standards/rag/`
- `tools/`
- `change_management/`
- `templates/`

Use cautiously or only when explicitly requested:

- `archive/`
- `exports/`
- `data/`

Do not treat as authoritative by default:

- `drafts/`
- `drafts_DO_NOT_READ/`
- `control-standards/drafts/`
- `control-standards/design_drafts/`

## Important Current Caveats

- The root [README.md](/Users/kyawminthu/Dev/Control System Tools/README.md) still describes a root-level `rag/` structure that no longer matches the current canonical path.
- [general_change_log.md](/Users/kyawminthu/Dev/Control System Tools/general_change_log.md) still contains migration-era references to `rag/` and "upcoming" work from 2026-01-15.
- `.claude/agents/` exists but its agent files are currently empty.
- `.mcp.json` exists but is currently empty.
- `tools/generate_rag_index.py` exists but is currently empty.

## Metadata And Safety Expectations

Authoritative standards files use metadata headers and paraphrased content. Maintain these rules:

- `AI_READ_ACCESS: ALLOWED` for AI-readable authoritative content
- no verbatim copyrighted standards text
- clear status such as `DRAFT`, `REVIEWED`, or `APPROVED`
- preserve traceability and internal routing indexes

## Useful Local Scripts

- `python3 tools/validate_ai_boundaries.py`: checks AI-readable content for required metadata and forbidden terms
- `python3 tools/fix_ai_boundaries.py`: repairs common metadata issues in AI-readable Markdown files
- `python3 tools/project_automator.py`: refreshes structure documentation and aggregates generation summaries

## Recommended Next Cleanup

If you are asked to improve project startup understanding further, prioritize this order:

1. Align the root [README.md](/Users/kyawminthu/Dev/Control System Tools/README.md) with the migrated `control-standards/rag/` structure.
2. Replace stale migration references in [general_change_log.md](/Users/kyawminthu/Dev/Control System Tools/general_change_log.md).
3. Implement `tools/generate_rag_index.py` or remove the empty placeholder.
4. Populate `.claude/agents/` and `.mcp.json` only if those integrations are actively used.

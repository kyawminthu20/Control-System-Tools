# RAG Directory Migration Guide
**Date:** 2026-01-15
**Purpose:** Consolidate two RAG directories into single authoritative location
**Status:** Ready for execution

## 🎯 Migration Overview

### Current Situation
You have **TWO RAG directories** with overlapping content:

1. **OLD Location**: `/Users/kyawminthu/Dev/tools/rag/`
   - 12 tool modules
   - 4 complete standards (NEC, NFPA 79, UL 508A, IEC 60204-1)
   - Original flat structure

2. **NEW Location**: `/Users/kyawminthu/Dev/tools/control-standards/rag/`
   - 5 core modules
   - 4 complete standards (same as OLD)
   - **NEW**: Overlap matrices (7 files)
   - **NEW**: Overlap notes (started, 4+ files)
   - Better governance structure
   - 4-tier architecture

### Migration Goal
- **Primary Location**: `control-standards/` becomes authoritative
- **Tool Modules**: Migrate to `control-standards/tools/`
- **OLD Location**: Archive and create symlink for compatibility
- **Result**: Single source of truth with better organization

## 📋 Pre-Migration Checklist

Before running migration:

### 1. Run Pre-Migration Check
```bash
cd /Users/kyawminthu/Dev/tools
./PRE_MIGRATION_CHECK.sh
```

Expected output:
- ✅ All PASS (green) - Ready to migrate
- ⚠️ Some WARN (yellow) - Review warnings, likely safe
- ❌ Any FAIL (red) - Fix issues before migrating

### 2. Verify You Have Backups
The migration script creates automatic backups, but verify:
- [ ] You have recent backups of your work
- [ ] You can restore from backup if needed
- [ ] No unsaved work in OLD directory

### 3. Review What Will Change
- [ ] OLD `/tools/rag/` will be moved to `_archive_old_rag_*/`
- [ ] NEW `/tools/control-standards/` becomes primary
- [ ] Symlink created: `/tools/rag/` → `/tools/control-standards/rag/`
- [ ] 7 tool modules moved to `/tools/control-standards/tools/`

## 🚀 Migration Steps

### Step 1: Run Pre-Migration Check
```bash
cd /Users/kyawminthu/Dev/tools
./PRE_MIGRATION_CHECK.sh
```

Review output and ensure no FAIL items.

### Step 2: Run Migration Script
```bash
cd /Users/kyawminthu/Dev/tools
./MIGRATION_SCRIPT.sh
```

The script will:
1. ✅ Create full backup of both directories
2. ✅ Compare standards content
3. ✅ Create `/tools/control-standards/tools/` directory
4. ✅ Migrate 7 tool modules from OLD to NEW
5. ✅ Copy any missing files
6. ✅ Archive OLD directory
7. ✅ Create symlink for backward compatibility
8. ✅ Generate migration summary

**Estimated Time**: 30-60 seconds

### Step 3: Verify Migration
```bash
# Check NEW primary location
ls -la /Users/kyawminthu/Dev/tools/control-standards/

# Check tools directory
ls -la /Users/kyawminthu/Dev/tools/control-standards/tools/

# Check symlink works
ls -la /Users/kyawminthu/Dev/tools/rag
# Should show: rag -> control-standards/rag
```

### Step 4: Review Migration Summary
```bash
cat /Users/kyawminthu/Dev/tools/control-standards/rag/MIGRATION_SUMMARY_*.md
```

## 📁 Directory Structure After Migration

```
/Users/kyawminthu/Dev/tools/
│
├── control-standards/                    # ✅ PRIMARY LOCATION
│   ├── rag/                             # Authoritative RAG content
│   │   ├── commissioning_checklists/
│   │   ├── design_framework/
│   │   ├── standards_intelligence/
│   │   │   ├── nec/                     # NEC 2023 (14 files)
│   │   │   ├── nfpa79/                  # NFPA 79 2024 (24 files)
│   │   │   ├── ul_508a/                 # UL 508A 2022 (15 files)
│   │   │   ├── iec_60204_1/             # IEC 60204-1 2018 (18 files)
│   │   │   ├── _overlap_matrix/         # ✨ NEW (7 files)
│   │   │   ├── _overlap_notes/          # ✨ NEW (4+ files)
│   │   │   ├── _glossary.md
│   │   │   ├── _standards_map.md
│   │   │   └── _index.yaml
│   │   ├── training_modules/
│   │   ├── troubleshooting_engine/
│   │   └── RAG_DIRECTORY_STATUS.md
│   │
│   ├── tools/                           # ✨ NEW - Migrated tool modules
│   │   ├── audit_tool/
│   │   ├── business_metrics_profit_engine/
│   │   ├── design_package_generator/
│   │   ├── ip_library_licensing/
│   │   ├── knowledge_platform/
│   │   ├── retainer_support_engine/
│   │   └── ul508a_panel_automation/
│   │
│   ├── design_drafts/                   # Working space
│   ├── drafts/                          # NO-AI zone
│   ├── exports/                         # Client deliverables
│   ├── README.md
│   ├── STRUCTURE_SUMMARY.md
│   └── QUICK_START.md
│
├── rag -> control-standards/rag/        # ✨ Symlink (backward compatibility)
│
├── _archive_old_rag_*/                  # ✨ OLD directory archived
│
├── _backup_before_migration_*/          # ✨ Full backup created
│
├── MIGRATION_SCRIPT.sh
├── PRE_MIGRATION_CHECK.sh
└── MIGRATION_GUIDE.md                   # This file
```

## 🔄 What Gets Migrated

### Standards Intelligence ✅ (Already in NEW)
- NEC 2023 (10 articles + 4 supporting files)
- NFPA 79 2024 (20 chapters + 4 supporting files)
- UL 508A 2022 (12 sections + 3 supporting files)
- IEC 60204-1 2018 (15 clauses + 3 supporting files)

### NEW Content ✨ (Only in NEW)
- **Overlap Matrices** (7 files):
  - UL 508A ↔ NEC ↔ NFPA 79 matrix
  - NFPA 79 ↔ IEC 60204-1 matrix
  - Master index and supporting files

- **Overlap Notes** (4+ files, 28 total planned):
  - SCCR determination note (CRITICAL)
  - Index and tracking files
  - 27 more to be created

### Tool Modules → /tools/ (From OLD)
1. audit_tool
2. business_metrics_profit_engine
3. design_package_generator
4. ip_library_licensing
5. knowledge_platform
6. retainer_support_engine
7. ul508a_panel_automation

### Core Modules ✅ (Already in NEW)
- commissioning_checklists
- design_framework
- training_modules
- troubleshooting_engine

## 🔒 Safety Features

### Automatic Backups
The migration script creates TWO backups:

1. **Full Backup** (before any changes):
   - Location: `_backup_before_migration_*/`
   - Contains: Complete copies of OLD and NEW
   - Purpose: Rollback if anything goes wrong

2. **Archive** (OLD directory preserved):
   - Location: `_archive_old_rag_*/`
   - Contains: Original OLD directory
   - Purpose: Reference and recovery

### Backward Compatibility
- **Symlink created**: `/tools/rag/` → `/tools/control-standards/rag/`
- **Old paths still work**: Any references to `/tools/rag/` automatically redirect
- **Zero breaking changes**: Existing scripts/tools continue working

### Non-Destructive
- No files deleted (only moved to archive)
- All content preserved
- Easy rollback available

## ❌ Rollback Procedure

If you need to undo the migration:

### Option 1: Restore from Backup (Safest)
```bash
# Remove symlink
rm /Users/kyawminthu/Dev/tools/rag

# Restore OLD from backup
cp -r /Users/kyawminthu/Dev/tools/_backup_before_migration_*/old_rag \
      /Users/kyawminthu/Dev/tools/rag

# Restore NEW from backup if needed
cp -r /Users/kyawminthu/Dev/tools/_backup_before_migration_*/new_rag \
      /Users/kyawminthu/Dev/tools/control-standards/rag
```

### Option 2: Restore from Archive
```bash
# Remove symlink
rm /Users/kyawminthu/Dev/tools/rag

# Move archive back
mv /Users/kyawminthu/Dev/tools/_archive_old_rag_* \
   /Users/kyawminthu/Dev/tools/rag
```

### Option 3: Keep Both (No Rollback Needed)
```bash
# Just remove symlink if you want both directories
rm /Users/kyawminthu/Dev/tools/rag

# Restore OLD from archive
mv /Users/kyawminthu/Dev/tools/_archive_old_rag_* \
   /Users/kyawminthu/Dev/tools/rag
```

## ✅ Post-Migration Tasks

### Immediate (After Migration)
1. ✅ Verify migration summary looks correct
2. ✅ Test symlink: `ls -la /Users/kyawminthu/Dev/tools/rag`
3. ✅ Check NEW location: `ls -la /Users/kyawminthu/Dev/tools/control-standards/`
4. ✅ Verify tools directory: `ls -la /Users/kyawminthu/Dev/tools/control-standards/tools/`

### Short-Term (Next 7 Days)
1. Update any hardcoded references to `/tools/rag/` → `/tools/control-standards/`
2. Test all tools work with new paths
3. Verify symlink functions correctly
4. Update documentation if needed

### Long-Term (After 30 Days)
1. If migration successful and no issues:
   - Can delete `_backup_before_migration_*/` (backup)
   - Can delete `_archive_old_rag_*/` (archived OLD)
   - Can remove symlink if desired (optional)

2. Continue development in NEW location
3. Build remaining overlap notes (27 files)
4. Develop 5 planned safety standards

## 🎁 Benefits of New Structure

### ✅ Organizational Improvements
- **Single source of truth** - No confusion about which directory is current
- **Better separation** - Tools in `/tools/`, core content in `/rag/`
- **Clear governance** - 4-tier architecture (rag, design_drafts, drafts, exports)
- **Complete documentation** - README, QUICK_START, STRUCTURE_SUMMARY

### ✅ New Content
- **Overlap matrices** - US standards + International comparison (7 files)
- **Overlap notes** - Detailed decision rules and checklists (28 files planned)
- **Glossary** - Shared terminology across standards
- **Standards map** - Applicability decision matrix

### ✅ Enhanced Features
- **Better cross-references** - Links between overlapping standards
- **Decision frameworks** - Which standard wins, when, and why
- **Evidence checklists** - What to collect for audits
- **Automation hooks** - Ready for SCCR calculator, etc.

## 📞 Troubleshooting

### Issue: Permission Denied
```bash
# Make scripts executable
chmod +x /Users/kyawminthu/Dev/tools/MIGRATION_SCRIPT.sh
chmod +x /Users/kyawminthu/Dev/tools/PRE_MIGRATION_CHECK.sh
```

### Issue: Disk Space Error
```bash
# Check available space
df -h /Users/kyawminthu/Dev/tools

# Free up space if needed (100MB required)
```

### Issue: Migration Script Fails Mid-Way
- **Don't panic** - Full backup exists at `_backup_before_migration_*/`
- **Check error message** - Script will show what failed
- **Rollback if needed** - Use rollback procedure above
- **Fix issue** - Resolve the error
- **Re-run** - Run migration script again

### Issue: Files Missing After Migration
- **Check archive** - `_archive_old_rag_*/` has original
- **Check backup** - `_backup_before_migration_*/` has full backup
- **Restore specific files** - Copy from backup/archive

## 📊 Migration Checklist

Print this checklist and check off items as you go:

### Pre-Migration
- [ ] Read this guide completely
- [ ] Run `PRE_MIGRATION_CHECK.sh`
- [ ] Resolve any FAIL items
- [ ] No unsaved work in OLD directory
- [ ] Ready to migrate

### Migration
- [ ] Run `MIGRATION_SCRIPT.sh`
- [ ] Script completes successfully
- [ ] Review migration summary
- [ ] No errors reported

### Verification
- [ ] NEW location exists and populated
- [ ] `/tools/` directory has 7 tool modules
- [ ] Symlink created: `/tools/rag/` → `/tools/control-standards/rag/`
- [ ] Archive created: `_archive_old_rag_*/`
- [ ] Backup created: `_backup_before_migration_*/`

### Post-Migration
- [ ] Test tools with new paths
- [ ] Update hardcoded path references
- [ ] Document any custom changes needed
- [ ] Mark migration complete

### Cleanup (After 30 Days)
- [ ] Delete backup directory (optional)
- [ ] Delete archive directory (optional)
- [ ] Remove symlink (optional)

## 🎯 Summary

**What**: Consolidate two RAG directories into one
**Why**: Better organization, new overlap matrices, single source of truth
**How**: Automated script with full backups and rollback
**When**: Ready to run now
**Risk**: Low (full backups, non-destructive, easy rollback)

**Next Step**: Run `./PRE_MIGRATION_CHECK.sh`

---

**Questions?** Review this guide or examine the migration scripts:
- `MIGRATION_SCRIPT.sh` - Main migration script
- `PRE_MIGRATION_CHECK.sh` - Pre-flight verification
- `MIGRATION_GUIDE.md` - This file

**Last Updated**: 2026-01-15

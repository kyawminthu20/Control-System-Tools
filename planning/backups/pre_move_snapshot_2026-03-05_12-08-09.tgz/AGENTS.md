# Project Instructions

Start each session by reading [PROJECT_STARTUP_CONTEXT.md](/Users/kyawminthu/Dev/Control System Tools/PROJECT_STARTUP_CONTEXT.md). Use [STRUCTURE_SUMMARY.md](/Users/kyawminthu/Dev/Control System Tools/STRUCTURE_SUMMARY.md) only as a current tree reference, not as the primary project narrative.

## Project Focus

This repository is an industrial automation knowledge base and tooling workspace. The canonical authoritative knowledge lives under `control-standards/rag/`.

## Canonical Paths

- `control-standards/rag/`: authoritative AI-readable standards and engineering knowledge
- `tools/`: local automation and validation scripts
- `change_management/`: governance and promotion workflow
- `templates/`: reusable authoring templates

## Treat As Secondary Or Noisy

- `archive/`: historical material, backups, superseded content
- `exports/`: generated output, not source knowledge
- `data/`: raw datasets and captures
- `.venv/`, `.git/`: environment and VCS internals

## Do Not Treat As Authoritative By Default

- `drafts/`
- `drafts_DO_NOT_READ/`
- `control-standards/drafts/`
- `control-standards/design_drafts/`

Only use draft material if the user explicitly asks for it, and clearly label it as non-authoritative.

## Working Rules

- Prefer `control-standards/rag/standards_intelligence/` for standards questions. It is the most populated part of the repo.
- Do not assume the root [README.md](/Users/kyawminthu/Dev/Control System Tools/README.md) is fully current; parts of it still describe the pre-migration `rag/` layout.
- Do not overstate completeness. Several module directories exist as scaffolding with little or no content yet.
- Preserve AI boundary rules: authoritative content is paraphrased guidance, not copyrighted standards text.
- When adding authoritative Markdown, include metadata such as `AI_READ_ACCESS`, `CONTENT_CLASS`, and `STATUS`.
- After structural or metadata changes, consider running `python3 tools/validate_ai_boundaries.py` and `python3 tools/project_automator.py`.

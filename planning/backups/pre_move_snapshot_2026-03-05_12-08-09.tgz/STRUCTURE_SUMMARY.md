# Folder Structure Summary


<!-- AUTO-GENERATED TREE START -->
## Directory Tree
**Last Auto-Updated:** 2026-03-05 11:46:56

```text
├── .claude/
│   ├── agents/
│   │   ├── rag-reviewer.md
│   │   └── standards-lookup.md
│   ├── settings.json
│   ├── settings.local.json
│   └── skills/
│       ├── new-rag-module/
│       │   └── SKILL.md
│       ├── promote-draft/
│       │   └── SKILL.md
│       └── validate-rag/
│           └── SKILL.md
├── .gemini/
├── .gitignore
├── .mcp.json
├── .python-version
├── .venv/
│   ├── .gitignore
│   ├── .lock
│   ├── CACHEDIR.TAG
│   ├── bin/
│   │   ├── activate
│   │   ├── activate.bat
│   │   ├── activate.csh
│   │   ├── activate.fish
│   │   ├── activate.nu
│   │   ├── activate.ps1
│   │   ├── activate_this.py
│   │   ├── deactivate.bat
│   │   ├── pydoc.bat
│   │   ├── python -> /Users/kyawminthu/.local/share/uv/python/cpython-3.13.5-macos-aarch64-none/bin/python3.13
│   │   ├── python3 -> python
│   │   └── python3.13 -> python
│   ├── lib/
│   │   └── python3.13/
│   │       └── site-packages/
│   │           ├── _virtualenv.pth
│   │           └── _virtualenv.py
│   └── pyvenv.cfg
├── MIGRATION_GUIDE.md
├── MIGRATION_READY.md
├── MIGRATION_SCRIPT.sh
├── PRE_MIGRATION_CHECK.sh
├── README.md
├── STRUCTURE_SUMMARY.md
├── archive/
│   ├── README.md
│   ├── _archive_old_rag_20260115_221742/
│   │   ├── _glossary.md
│   │   ├── _index.yaml
│   │   ├── _standards_map.md
│   │   ├── audit_tool/
│   │   │   ├── README.md
│   │   │   ├── outputs/
│   │   │   └── report_templates/
│   │   ├── business_metrics_profit_engine/
│   │   │   ├── README.md
│   │   │   └── exports/
│   │   ├── commissioning_checklists/
│   │   │   ├── README.md
│   │   │   ├── checklists/
│   │   │   └── outputs/
│   │   ├── design_framework/
│   │   │   ├── README.md
│   │   │   ├── constraints/
│   │   │   ├── design_guides/
│   │   │   │   └── 01_panel_design_guide.md
│   │   │   ├── outputs/
│   │   │   └── patterns/
│   │   │       └── io_templates.yaml
│   │   ├── design_package_generator/
│   │   │   ├── README.md
│   │   │   └── kits/
│   │   │       ├── conveyor_control_kit/
│   │   │       ├── pump_skid_control_kit/
│   │   │       └── robotic_cell_control_kit/
│   │   ├── ip_library_licensing/
│   │   │   ├── README.md
│   │   │   └── export_packages/
│   │   ├── knowledge_platform/
│   │   │   └── README.md
│   │   ├── retainer_support_engine/
│   │   │   ├── README.md
│   │   │   └── outputs/
│   │   ├── standards_intelligence/
│   │   │   ├── ISO_IEC/
│   │   │   │   ├── README.md
│   │   │   │   └── iec_60204_1/
│   │   │   ├── NEC/
│   │   │   ├── NFPA/
│   │   │   ├── UL/
│   │   │   ├── clause_index/
│   │   │   │   ├── iso_iec_clause_index.yaml
│   │   │   │   ├── nec_clause_index.yaml
│   │   │   │   ├── nfpa79_clause_index.yaml
│   │   │   │   └── ul508a_clause_index.yaml
│   │   │   ├── outputs/
│   │   │   │   └── standards_guidance_report.md
│   │   │   └── rules_engine/
│   │   │       ├── red_flags.yaml
│   │   │       └── rules.yaml
│   │   ├── training_cert_builder/
│   │   │   ├── README.md
│   │   │   ├── assessments/
│   │   │   └── modules/
│   │   ├── troubleshooting_decision_engine/
│   │   │   ├── README.md
│   │   │   ├── decision_trees/
│   │   │   ├── outputs/
│   │   │   └── playbooks/
│   │   └── ul508a_panel_automation/
│   │       ├── README.md
│   │       ├── outputs/
│   │       └── ul_documentation_templates/
│   ├── _backup_before_migration_20260115_221742/
│   │   ├── new_rag/
│   │   │   ├── RAG_DIRECTORY_STATUS.md
│   │   │   ├── commissioning_checklists/
│   │   │   │   ├── dry_run/
│   │   │   │   ├── handover/
│   │   │   │   ├── live_run/
│   │   │   │   └── pre_power/
│   │   │   ├── design_framework/
│   │   │   │   ├── control_system_design/
│   │   │   │   ├── io_architecture/
│   │   │   │   ├── network_architecture/
│   │   │   │   ├── power_distribution/
│   │   │   │   ├── safety_architecture/
│   │   │   │   └── us_eu_compliance_wizard/
│   │   │   ├── standards_intelligence/
│   │   │   │   ├── COMPLETE_STANDARDS_PORTFOLIO.md
│   │   │   │   ├── README.md
│   │   │   │   ├── STANDARDS_MODULES_SUMMARY.md
│   │   │   │   ├── _glossary.md
│   │   │   │   ├── _index.yaml
│   │   │   │   ├── _overlap_matrix/
│   │   │   │   │   ├── _index.yaml
│   │   │   │   │   ├── file_structure.md
│   │   │   │   │   ├── nfpa79_iec60204_overlap.md
│   │   │   │   │   ├── standards_decision_workflow.md
│   │   │   │   │   ├── standards_overlap.md
│   │   │   │   │   └── ul508a_nec_nfpa79_overlap.md
│   │   │   │   ├── _overlap_notes/
│   │   │   │   │   ├── GENERATION_STATUS.md
│   │   │   │   │   ├── _index.yaml
│   │   │   │   │   ├── file_structure.md
│   │   │   │   │   └── overlap__sccr.md
│   │   │   │   ├── _standards_map.md
│   │   │   │   ├── iec_60204_1/
│   │   │   │   │   ├── GENERATION_SUMMARY.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause01__scope.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause02__normative_references.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause03__terms_and_definitions.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause04__general_requirements.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause05__incoming_supply.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause06__protection_against_electric_shock.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause07__protection_of_equipment.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause08__equipotential_bonding.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause09__control_circuits_and_functions.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause10__operator_interface.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause11__control_equipment.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause12__motors_and_drives.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause13__accessories_and_lighting.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause14__marking_and_documentation.md
│   │   │   │   │   ├── IEC60204_1_2018__Clause15__verification.md
│   │   │   │   │   ├── IEC60204_OVERVIEW.md
│   │   │   │   │   ├── README.md
│   │   │   │   │   └── _index.yaml
│   │   │   │   ├── iec_61508/
│   │   │   │   ├── iec_61511/
│   │   │   │   ├── iec_62061/
│   │   │   │   ├── iso_12100/
│   │   │   │   ├── iso_13849_1/
│   │   │   │   │   └── file_structure.md
│   │   │   │   ├── nec/
│   │   │   │   │   ├── GENERATION_SUMMARY.md
│   │   │   │   │   ├── NEC_2023__Art110__requirements_for_electrical_installations.md
│   │   │   │   │   ├── NEC_2023__Art240__overcurrent_protection.md
│   │   │   │   │   ├── NEC_2023__Art250__grounding_and_bonding.md
│   │   │   │   │   ├── NEC_2023__Art300__general_wiring_methods.md
│   │   │   │   │   ├── NEC_2023__Art310__conductors_for_general_wiring.md
│   │   │   │   │   ├── NEC_2023__Art408__switchboards_switchgear_and_panelboards.md
│   │   │   │   │   ├── NEC_2023__Art409__industrial_control_panels.md
│   │   │   │   │   ├── NEC_2023__Art430__motors_motor_circuits_and_controllers.md
│   │   │   │   │   ├── NEC_2023__Art670__industrial_machinery.md
│   │   │   │   │   ├── NEC_2023__Art725__class_1_2_3_control_circuits.md
│   │   │   │   │   ├── NEC_OVERVIEW.md
│   │   │   │   │   ├── README.md
│   │   │   │   │   └── _index.yaml
│   │   │   │   ├── nfpa79/
│   │   │   │   │   ├── GENERATION_SUMMARY.md
│   │   │   │   │   ├── NFPA79_2024__Ch01__administration.md
│   │   │   │   │   ├── NFPA79_2024__Ch02__definitions.md
│   │   │   │   │   ├── NFPA79_2024__Ch03__general_requirements.md
│   │   │   │   │   ├── NFPA79_2024__Ch04__general_conditions_of_installation.md
│   │   │   │   │   ├── NFPA79_2024__Ch05__disconnecting_means.md
│   │   │   │   │   ├── NFPA79_2024__Ch06__overcurrent_protection.md
│   │   │   │   │   ├── NFPA79_2024__Ch07__protection_against_electric_shock.md
│   │   │   │   │   ├── NFPA79_2024__Ch08__grounding_and_bonding.md
│   │   │   │   │   ├── NFPA79_2024__Ch09__control_circuits_and_control_functions.md
│   │   │   │   │   ├── NFPA79_2024__Ch10__operator_interface_devices.md
│   │   │   │   │   ├── NFPA79_2024__Ch11__control_equipment.md
│   │   │   │   │   ├── NFPA79_2024__Ch12__motors_and_associated_equipment.md
│   │   │   │   │   ├── NFPA79_2024__Ch13__appliances_and_accessories.md
│   │   │   │   │   ├── NFPA79_2024__Ch14__lighting.md
│   │   │   │   │   ├── NFPA79_2024__Ch15__transformers_and_power_supplies.md
│   │   │   │   │   ├── NFPA79_2024__Ch16__wiring_methods.md
│   │   │   │   │   ├── NFPA79_2024__Ch17__cables_and_flexible_cords.md
│   │   │   │   │   ├── NFPA79_2024__Ch18__terminal_blocks_and_connectors.md
│   │   │   │   │   ├── NFPA79_2024__Ch19__marking_and_documentation.md
│   │   │   │   │   ├── NFPA79_2024__Ch20__system_integration.md
│   │   │   │   │   ├── NFPA_OVERVIEW.md
│   │   │   │   │   ├── README.md
│   │   │   │   │   └── _index.yaml
│   │   │   │   ├── standards_applicability.md
│   │   │   │   └── ul_508a/
│   │   │   │       ├── GENERATION_SUMMARY.md
│   │   │   │       ├── README.md
│   │   │   │       ├── UL508A_2022__control_circuits_and_devices.md
│   │   │   │       ├── UL508A_2022__enclosures_and_environmental_ratings.md
│   │   │   │       ├── UL508A_2022__general_construction_requirements.md
│   │   │   │       ├── UL508A_2022__grounding_and_bonding.md
│   │   │   │       ├── UL508A_2022__marking_and_documentation.md
│   │   │   │       ├── UL508A_2022__motor_controllers_and_drives.md
│   │   │   │       ├── UL508A_2022__overcurrent_protection.md
│   │   │   │       ├── UL508A_2022__sccr_short_circuit_current_rating.md
│   │   │   │       ├── UL508A_2022__scope_and_application.md
│   │   │   │       ├── UL508A_2022__spacing_creepage_clearance.md
│   │   │   │       ├── UL508A_2022__transformers_and_power_supplies.md
│   │   │   │       ├── UL508A_2022__wiring_methods_and_conductors.md
│   │   │   │       ├── UL508A_OVERVIEW.md
│   │   │   │       └── _index.yaml
│   │   │   ├── training_modules/
│   │   │   │   ├── commissioning/
│   │   │   │   ├── fundamentals/
│   │   │   │   ├── safety/
│   │   │   │   └── troubleshooting/
│   │   │   └── troubleshooting_engine/
│   │   │       ├── analog_io/
│   │   │       ├── decision_trees.yaml
│   │   │       ├── digital_io/
│   │   │       ├── motion_servo/
│   │   │       ├── networks/
│   │   │       └── pid_control/
│   │   └── old_rag/
│   │       ├── _glossary.md
│   │       ├── _index.yaml
│   │       ├── _standards_map.md
│   │       ├── audit_tool/
│   │       │   ├── README.md
│   │       │   ├── outputs/
│   │       │   └── report_templates/
│   │       ├── business_metrics_profit_engine/
│   │       │   ├── README.md
│   │       │   └── exports/
│   │       ├── commissioning_checklists/
│   │       │   ├── README.md
│   │       │   ├── checklists/
│   │       │   └── outputs/
│   │       ├── design_framework/
│   │       │   ├── README.md
│   │       │   ├── constraints/
│   │       │   ├── design_guides/
│   │       │   │   └── 01_panel_design_guide.md
│   │       │   ├── outputs/
│   │       │   └── patterns/
│   │       │       └── io_templates.yaml
│   │       ├── design_package_generator/
│   │       │   ├── README.md
│   │       │   └── kits/
│   │       │       ├── conveyor_control_kit/
│   │       │       ├── pump_skid_control_kit/
│   │       │       └── robotic_cell_control_kit/
│   │       ├── ip_library_licensing/
│   │       │   ├── README.md
│   │       │   └── export_packages/
│   │       ├── knowledge_platform/
│   │       │   └── README.md
│   │       ├── retainer_support_engine/
│   │       │   ├── README.md
│   │       │   └── outputs/
│   │       ├── standards_intelligence/
│   │       │   ├── ISO_IEC/
│   │       │   │   ├── README.md
│   │       │   │   └── iec_60204_1/
│   │       │   ├── NEC/
│   │       │   ├── NFPA/
│   │       │   ├── UL/
│   │       │   ├── clause_index/
│   │       │   │   ├── iso_iec_clause_index.yaml
│   │       │   │   ├── nec_clause_index.yaml
│   │       │   │   ├── nfpa79_clause_index.yaml
│   │       │   │   └── ul508a_clause_index.yaml
│   │       │   ├── outputs/
│   │       │   │   └── standards_guidance_report.md
│   │       │   └── rules_engine/
│   │       │       ├── red_flags.yaml
│   │       │       └── rules.yaml
│   │       ├── training_cert_builder/
│   │       │   ├── README.md
│   │       │   ├── assessments/
│   │       │   └── modules/
│   │       ├── troubleshooting_decision_engine/
│   │       │   ├── README.md
│   │       │   ├── decision_trees/
│   │       │   ├── outputs/
│   │       │   └── playbooks/
│   │       └── ul508a_panel_automation/
│   │           ├── README.md
│   │           ├── outputs/
│   │           └── ul_documentation_templates/
│   ├── old_decision_trees/
│   ├── past_audits/
│   └── superseded_designs/
├── change_management/
│   ├── README.md
│   ├── decision_log.md
│   ├── design_change_policy.md
│   ├── promotion_checklist_drafts_to_rag.md
│   └── release_notes.md
├── control-standards/
│   ├── QUICK_START.md
│   ├── README.md
│   ├── STRUCTURE_SUMMARY.md
│   ├── design_drafts/
│   │   ├── README.md
│   │   ├── diagrams/
│   │   ├── experiments/
│   │   └── scratch_notes/
│   ├── drafts/
│   │   ├── README.md
│   │   ├── copied_standard_text/
│   │   ├── raw_notes/
│   │   └── vendor_docs/
│   ├── exports/
│   │   ├── README.md
│   │   ├── docx/
│   │   ├── pdf/
│   │   └── reports/
│   ├── rag/
│   │   ├── MIGRATION_SUMMARY_20260115_221742.md
│   │   ├── RAG_DIRECTORY_STATUS.md
│   │   ├── commissioning_checklists/
│   │   │   ├── dry_run/
│   │   │   ├── handover/
│   │   │   ├── live_run/
│   │   │   └── pre_power/
│   │   ├── design_framework/
│   │   │   ├── control_system_design/
│   │   │   ├── io_architecture/
│   │   │   ├── network_architecture/
│   │   │   ├── power_distribution/
│   │   │   ├── safety_architecture/
│   │   │   └── us_eu_compliance_wizard/
│   │   ├── standards_intelligence/
│   │   │   ├── COMPLETE_STANDARDS_PORTFOLIO.md
│   │   │   ├── README.md
│   │   │   ├── STANDARDS_COMPLETION_STATUS.md
│   │   │   ├── STANDARDS_MODULES_SUMMARY.md
│   │   │   ├── _glossary.md
│   │   │   ├── _index.yaml
│   │   │   ├── _overlap_matrix/
│   │   │   │   ├── _index.yaml
│   │   │   │   ├── file_structure.md
│   │   │   │   ├── nfpa79_iec60204_overlap.md
│   │   │   │   ├── standards_decision_workflow.md
│   │   │   │   ├── standards_overlap.md
│   │   │   │   └── ul508a_nec_nfpa79_overlap.md
│   │   │   ├── _overlap_notes/
│   │   │   │   ├── GENERATION_STATUS.md
│   │   │   │   ├── _index.yaml
│   │   │   │   ├── file_structure.md
│   │   │   │   └── overlap__sccr.md
│   │   │   ├── _standards_map.md
│   │   │   ├── iec_60204_1/
│   │   │   │   ├── GENERATION_SUMMARY.md
│   │   │   │   ├── IEC60204_1_2018__Clause01__scope.md
│   │   │   │   ├── IEC60204_1_2018__Clause02__normative_references.md
│   │   │   │   ├── IEC60204_1_2018__Clause03__terms_and_definitions.md
│   │   │   │   ├── IEC60204_1_2018__Clause04__general_requirements.md
│   │   │   │   ├── IEC60204_1_2018__Clause05__incoming_supply.md
│   │   │   │   ├── IEC60204_1_2018__Clause06__protection_against_electric_shock.md
│   │   │   │   ├── IEC60204_1_2018__Clause07__protection_of_equipment.md
│   │   │   │   ├── IEC60204_1_2018__Clause08__equipotential_bonding.md
│   │   │   │   ├── IEC60204_1_2018__Clause09__control_circuits_and_functions.md
│   │   │   │   ├── IEC60204_1_2018__Clause10__operator_interface.md
│   │   │   │   ├── IEC60204_1_2018__Clause11__control_equipment.md
│   │   │   │   ├── IEC60204_1_2018__Clause12__motors_and_drives.md
│   │   │   │   ├── IEC60204_1_2018__Clause13__accessories_and_lighting.md
│   │   │   │   ├── IEC60204_1_2018__Clause14__marking_and_documentation.md
│   │   │   │   ├── IEC60204_1_2018__Clause15__verification.md
│   │   │   │   ├── IEC60204_OVERVIEW.md
│   │   │   │   ├── README.md
│   │   │   │   └── _index.yaml
│   │   │   ├── iec_61508/
│   │   │   ├── iec_61511/
│   │   │   ├── iec_62061/
│   │   │   ├── iso_12100/
│   │   │   ├── iso_13849_1/
│   │   │   │   └── file_structure.md
│   │   │   ├── nec/
│   │   │   │   ├── GENERATION_SUMMARY.md
│   │   │   │   ├── NEC_2023__Art110__requirements_for_electrical_installations.md
│   │   │   │   ├── NEC_2023__Art240__overcurrent_protection.md
│   │   │   │   ├── NEC_2023__Art250__grounding_and_bonding.md
│   │   │   │   ├── NEC_2023__Art300__general_wiring_methods.md
│   │   │   │   ├── NEC_2023__Art310__conductors_for_general_wiring.md
│   │   │   │   ├── NEC_2023__Art408__switchboards_switchgear_and_panelboards.md
│   │   │   │   ├── NEC_2023__Art409__industrial_control_panels.md
│   │   │   │   ├── NEC_2023__Art430__motors_motor_circuits_and_controllers.md
│   │   │   │   ├── NEC_2023__Art670__industrial_machinery.md
│   │   │   │   ├── NEC_2023__Art725__class_1_2_3_control_circuits.md
│   │   │   │   ├── NEC_COMPLETION_STATUS.md
│   │   │   │   ├── NEC_OVERVIEW.md
│   │   │   │   ├── README.md
│   │   │   │   └── _index.yaml
│   │   │   ├── nfpa79/
│   │   │   │   ├── GENERATION_SUMMARY.md
│   │   │   │   ├── NFPA79_2024__Ch01__administration.md
│   │   │   │   ├── NFPA79_2024__Ch02__definitions.md
│   │   │   │   ├── NFPA79_2024__Ch03__general_requirements.md
│   │   │   │   ├── NFPA79_2024__Ch04__general_conditions_of_installation.md
│   │   │   │   ├── NFPA79_2024__Ch05__disconnecting_means.md
│   │   │   │   ├── NFPA79_2024__Ch06__overcurrent_protection.md
│   │   │   │   ├── NFPA79_2024__Ch07__protection_against_electric_shock.md
│   │   │   │   ├── NFPA79_2024__Ch08__grounding_and_bonding.md
│   │   │   │   ├── NFPA79_2024__Ch09__control_circuits_and_control_functions.md
│   │   │   │   ├── NFPA79_2024__Ch10__operator_interface_devices.md
│   │   │   │   ├── NFPA79_2024__Ch11__control_equipment.md
│   │   │   │   ├── NFPA79_2024__Ch12__motors_and_associated_equipment.md
│   │   │   │   ├── NFPA79_2024__Ch13__appliances_and_accessories.md
│   │   │   │   ├── NFPA79_2024__Ch14__lighting.md
│   │   │   │   ├── NFPA79_2024__Ch15__transformers_and_power_supplies.md
│   │   │   │   ├── NFPA79_2024__Ch16__wiring_methods.md
│   │   │   │   ├── NFPA79_2024__Ch17__cables_and_flexible_cords.md
│   │   │   │   ├── NFPA79_2024__Ch18__terminal_blocks_and_connectors.md
│   │   │   │   ├── NFPA79_2024__Ch19__marking_and_documentation.md
│   │   │   │   ├── NFPA79_2024__Ch20__system_integration.md
│   │   │   │   ├── NFPA_OVERVIEW.md
│   │   │   │   ├── README.md
│   │   │   │   └── _index.yaml
│   │   │   ├── standards_applicability.md
│   │   │   └── ul_508a/
│   │   │       ├── GENERATION_SUMMARY.md
│   │   │       ├── README.md
│   │   │       ├── UL508A_2022__control_circuits_and_devices.md
│   │   │       ├── UL508A_2022__enclosures_and_environmental_ratings.md
│   │   │       ├── UL508A_2022__general_construction_requirements.md
│   │   │       ├── UL508A_2022__grounding_and_bonding.md
│   │   │       ├── UL508A_2022__marking_and_documentation.md
│   │   │       ├── UL508A_2022__motor_controllers_and_drives.md
│   │   │       ├── UL508A_2022__overcurrent_protection.md
│   │   │       ├── UL508A_2022__sccr_short_circuit_current_rating.md
│   │   │       ├── UL508A_2022__scope_and_application.md
│   │   │       ├── UL508A_2022__spacing_creepage_clearance.md
│   │   │       ├── UL508A_2022__transformers_and_power_supplies.md
│   │   │       ├── UL508A_2022__wiring_methods_and_conductors.md
│   │   │       ├── UL508A_OVERVIEW.md
│   │   │       └── _index.yaml
│   │   ├── training_modules/
│   │   │   ├── commissioning/
│   │   │   ├── fundamentals/
│   │   │   ├── safety/
│   │   │   └── troubleshooting/
│   │   └── troubleshooting_engine/
│   │       ├── analog_io/
│   │       ├── decision_trees.yaml
│   │       ├── digital_io/
│   │       ├── motion_servo/
│   │       ├── networks/
│   │       └── pid_control/
│   └── tools/
│       ├── audit_tool/
│       │   ├── README.md
│       │   ├── outputs/
│       │   └── report_templates/
│       ├── business_metrics_profit_engine/
│       │   ├── README.md
│       │   └── exports/
│       ├── design_package_generator/
│       │   ├── README.md
│       │   └── kits/
│       │       ├── conveyor_control_kit/
│       │       ├── pump_skid_control_kit/
│       │       └── robotic_cell_control_kit/
│       ├── ip_library_licensing/
│       │   ├── README.md
│       │   └── export_packages/
│       ├── knowledge_platform/
│       │   └── README.md
│       ├── retainer_support_engine/
│       │   ├── README.md
│       │   └── outputs/
│       └── ul508a_panel_automation/
│           ├── README.md
│           ├── outputs/
│           └── ul_documentation_templates/
├── data/
│   ├── README.md
│   ├── historian_exports/
│   ├── network_captures/
│   └── plc_exports/
├── drafts/
│   ├── 00_inbox_notes.md
│   ├── README.md
│   ├── commissioning_notes/
│   ├── design_working/
│   ├── experiments/
│   ├── standards_notes/
│   └── troubleshooting_logs/
├── drafts_DO_NOT_READ/
│   ├── DELIVERABLE.md
│   ├── PROJECT_STRUCTURE 4.59.29 PM.md
│   ├── QUICK_START.md
│   ├── README.md
│   └── control_system_project_template.tar.gz
├── exports/
│   ├── README.md
│   ├── csv/
│   ├── pdf/
│   └── snapshots/
├── general_change_log.md
├── main.py
├── pyproject.toml
├── rag -> /Users/kyawminthu/Dev/tools/control-standards/rag
├── templates/
│   ├── README.md
│   ├── checklists/
│   ├── design_guides/
│   ├── md_headers/
│   │   ├── draft_only_header.md
│   │   └── rag_approved_header.md
│   └── reports/
├── tools/
│   ├── README.md
│   ├── fix_ai_boundaries.py
│   ├── generate_rag_index.py
│   ├── project_automator.py
│   ├── setup_hooks.sh
│   └── validate_ai_boundaries.py
└── uv.lock
```
<!-- AUTO-GENERATED TREE END -->

**Created:** 2026-01-15

## What Was Built

A complete Industrial Automation Intelligence Platform with a three-tier knowledge management architecture designed for safe AI-assisted engineering work.

## Directory Statistics

- **Total Directories Created**: 66
- **Total Files Created**: 36+
- **Main Sections**: 8

## Key Directories

### 1. `/rag/` - Authoritative Knowledge (AI-ALLOWED)

**12 Tool Modules:**

- ✅ standards_intelligence/ - With clause indexes, rules engine, red flags
- ✅ design_framework/ - With design guides, patterns, constraints
- ✅ troubleshooting_decision_engine/ - Structure ready for decision trees
- ✅ commissioning_checklists/ - Framework established
- ✅ audit_tool/ - Scoring model structure
- ✅ design_package_generator/ - Kit structures (conveyor, pump, robotic)
- ✅ retainer_support_engine/ - Support framework
- ✅ knowledge_platform/ - Navigation structure
- ✅ ul508a_panel_automation/ - Template system
- ✅ training_cert_builder/ - Module structure
- ✅ ip_library_licensing/ - Licensing framework
- ✅ business_metrics_profit_engine/ - Metrics schema

**Core Files:**

- ✅ \_index.yaml - RAG routing rules + AI access control
- ✅ \_glossary.md - Approved terminology
- ✅ \_standards_map.md - Standards applicability matrix

### 2. `/drafts/` - Working Space (AI-FORBIDDEN)

- ✅ 00_inbox_notes.md - Quick capture
- ✅ Subdirectories for standards, design, troubleshooting, commissioning, experiments

### 3. `/archive/` - Historical Record (MANUAL-ONLY)

- ✅ Structure for superseded designs, old decision trees, past audits

### 4. `/change_management/` - Quality Gates

- ✅ promotion_checklist_drafts_to_rag.md
- ✅ design_change_policy.md
- ✅ decision_log.md
- ✅ release_notes.md

### 5. `/templates/` - Content Templates

- ✅ Headers for RAG, drafts, archive
- ✅ Template structure for guides, reports, checklists

### 6. `/exports/` - Deliverables

- ✅ pdf/, csv/, snapshots/ directories

### 7. `/tools/` - Automation Scripts

- ✅ Structure for validation and generation scripts

### 8. `/data/` - Datasets

- ✅ plc_exports/, network_captures/, historian_exports/

## What Has Content vs. Structure Only

### Files with Rich Content

1. **README.md** (project root) - Comprehensive overview
2. **rag/\_index.yaml** - Complete routing rules
3. **rag/\_glossary.md** - Initial terminology (A-U)
4. **rag/\_standards_map.md** - Standards applicability matrix
5. **rag/standards_intelligence/standards_applicability.md** - Project type mappings
6. **rag/standards_intelligence/clause_index/\*.yaml** - All 4 standard indexes (NEC, NFPA 79, UL 508A, ISO/IEC)
7. **rag/standards_intelligence/rules_engine/rules.yaml** - Design rules (wire, grounding, spacing, motor, safety)
8. **rag/standards_intelligence/rules_engine/red_flags.yaml** - 10 common compliance issues
9. **rag/design_framework/design_guides/01_panel_design_guide.md** - Complete guide
10. **rag/design_framework/patterns/io_templates.yaml** - DI, DO, AI, AO patterns
11. **change_management/\*.md** - All 4 policy/process documents
12. **templates/md_headers/\*.md** - Template headers

### Files with Placeholder Content (Ready to Expand)

- All tool READMEs (12 tools)
- Output templates
- Additional design guides (02-07 planned)
- Decision trees and playbooks
- Commissioning checklists
- Audit tool scoring models
- Design package kits (structure exists, needs detail)

## Next Steps

### Immediate (Content Development)

1. Expand troubleshooting decision trees
2. Complete design guide series (guides 02-07)
3. Populate commissioning checklists with detailed steps
4. Add commissioning checklist content
5. Develop design package kit details (BOMs, diagrams)

### Short-term (Automation)

1. Create validate_ai_boundaries scripts (.sh and .ps1)
2. Implement report generation scripts
3. Build BOM generator for UL 508A tool
4. Create PDF export tooling

### Medium-term (Integration)

1. Decision tree interactive interface
2. Audit tool scoring implementation
3. Business metrics dashboard
4. Training module assessments

## How to Use This Structure

### For Engineers

Start at [README.md](README.md) → Browse `/rag/` → Use tool-specific READMEs

### For Contributors

Start at [change_management/README.md](change_management/README.md) → Work in `/drafts/` → Promote to `/rag/`

### For AI Developers

Configure AI to read ONLY `/rag/**` → Use [rag/\_index.yaml](rag/_index.yaml) for routing

## Validation Checklist

✅ Three-tier architecture implemented
✅ AI access controls defined (\_index.yaml)
✅ All 12 tool modules structured
✅ Core standards content created
✅ Change management processes documented
✅ Template library established
✅ Project README comprehensive
✅ Glossary started
✅ Standards map complete
✅ Changelog discipline enforced

## Statistics

| Category                | Count                              |
| ----------------------- | ---------------------------------- |
| Total directories       | 66                                 |
| Tool modules            | 12                                 |
| Standards indexed       | 4 (NEC, NFPA 79, UL 508A, ISO/IEC) |
| Design rules defined    | 15+                                |
| Red flags cataloged     | 10                                 |
| I/O patterns documented | 8                                  |
| Design guides started   | 1 (7 planned)                      |
| README files created    | 20+                                |
| Policy documents        | 4                                  |

---

**Status:** Foundation Complete ✅
**Version:** 1.0
**Ready for:** Content expansion and automation development

(Control System Tools) ➜ Control System Tools git:(master) ✗ tree
.
├── archive
│ ├── \_archive_old_rag_20260115_221742
│ │ ├── \_glossary.md
│ │ ├── \_index.yaml
│ │ ├── \_standards_map.md
│ │ ├── audit_tool
│ │ │ ├── outputs
│ │ │ ├── README.md
│ │ │ └── report_templates
│ │ ├── business_metrics_profit_engine
│ │ │ ├── exports
│ │ │ └── README.md
│ │ ├── commissioning_checklists
│ │ │ ├── checklists
│ │ │ ├── outputs
│ │ │ └── README.md
│ │ ├── design_framework
│ │ │ ├── constraints
│ │ │ ├── design_guides
│ │ │ │ └── 01_panel_design_guide.md
│ │ │ ├── outputs
│ │ │ ├── patterns
│ │ │ │ └── io_templates.yaml
│ │ │ └── README.md
│ │ ├── design_package_generator
│ │ │ ├── kits
│ │ │ │ ├── conveyor_control_kit
│ │ │ │ ├── pump_skid_control_kit
│ │ │ │ └── robotic_cell_control_kit
│ │ │ └── README.md
│ │ ├── ip_library_licensing
│ │ │ ├── export_packages
│ │ │ └── README.md
│ │ ├── knowledge_platform
│ │ │ └── README.md
│ │ ├── retainer_support_engine
│ │ │ ├── outputs
│ │ │ └── README.md
│ │ ├── standards_intelligence
│ │ │ ├── clause_index
│ │ │ │ ├── iso_iec_clause_index.yaml
│ │ │ │ ├── nec_clause_index.yaml
│ │ │ │ ├── nfpa79_clause_index.yaml
│ │ │ │ └── ul508a_clause_index.yaml
│ │ │ ├── ISO_IEC
│ │ │ │ ├── iec_60204_1
│ │ │ │ └── README.md
│ │ │ ├── NEC
│ │ │ ├── NFPA
│ │ │ ├── outputs
│ │ │ │ └── standards_guidance_report.md
│ │ │ ├── rules_engine
│ │ │ │ ├── red_flags.yaml
│ │ │ │ └── rules.yaml
│ │ │ └── UL
│ │ ├── training_cert_builder
│ │ │ ├── assessments
│ │ │ ├── modules
│ │ │ └── README.md
│ │ ├── troubleshooting_decision_engine
│ │ │ ├── decision_trees
│ │ │ ├── outputs
│ │ │ ├── playbooks
│ │ │ └── README.md
│ │ └── ul508a_panel_automation
│ │ ├── outputs
│ │ ├── README.md
│ │ └── ul_documentation_templates
│ ├── \_backup_before_migration_20260115_221742
│ │ ├── new_rag
│ │ │ ├── commissioning_checklists
│ │ │ │ ├── dry_run
│ │ │ │ ├── handover
│ │ │ │ ├── live_run
│ │ │ │ └── pre_power
│ │ │ ├── design_framework
│ │ │ │ ├── control_system_design
│ │ │ │ ├── io_architecture
│ │ │ │ ├── network_architecture
│ │ │ │ ├── power_distribution
│ │ │ │ ├── safety_architecture
│ │ │ │ └── us_eu_compliance_wizard
│ │ │ ├── RAG_DIRECTORY_STATUS.md
│ │ │ ├── standards_intelligence
│ │ │ │ ├── \_glossary.md
│ │ │ │ ├── \_index.yaml
│ │ │ │ ├── \_overlap_matrix
│ │ │ │ │ ├── \_index.yaml
│ │ │ │ │ ├── file_structure.md
│ │ │ │ │ ├── nfpa79_iec60204_overlap.md
│ │ │ │ │ ├── standards_decision_workflow.md
│ │ │ │ │ ├── standards_overlap.md
│ │ │ │ │ └── ul508a_nec_nfpa79_overlap.md
│ │ │ │ ├── \_overlap_notes
│ │ │ │ │ ├── \_index.yaml
│ │ │ │ │ ├── file_structure.md
│ │ │ │ │ ├── GENERATION_STATUS.md
│ │ │ │ │ └── overlap**sccr.md
│ │ │ │ ├── \_standards_map.md
│ │ │ │ ├── COMPLETE_STANDARDS_PORTFOLIO.md
│ │ │ │ ├── iec_60204_1
│ │ │ │ │ ├── \_index.yaml
│ │ │ │ │ ├── GENERATION_SUMMARY.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause01**scope.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause02**normative_references.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause03**terms_and_definitions.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause04**general_requirements.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause05**incoming_supply.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause06**protection_against_electric_shock.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause07**protection_of_equipment.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause08**equipotential_bonding.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause09**control_circuits_and_functions.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause10**operator_interface.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause11**control_equipment.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause12**motors_and_drives.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause13**accessories_and_lighting.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause14**marking_and_documentation.md
│ │ │ │ │ ├── IEC60204_1_2018**Clause15**verification.md
│ │ │ │ │ ├── IEC60204_OVERVIEW.md
│ │ │ │ │ └── README.md
│ │ │ │ ├── iec_61508
│ │ │ │ ├── iec_61511
│ │ │ │ ├── iec_62061
│ │ │ │ ├── iso_12100
│ │ │ │ ├── iso_13849_1
│ │ │ │ │ └── file_structure.md
│ │ │ │ ├── nec
│ │ │ │ │ ├── \_index.yaml
│ │ │ │ │ ├── GENERATION_SUMMARY.md
│ │ │ │ │ ├── NEC_2023**Art110**requirements_for_electrical_installations.md
│ │ │ │ │ ├── NEC_2023**Art240**overcurrent_protection.md
│ │ │ │ │ ├── NEC_2023**Art250**grounding_and_bonding.md
│ │ │ │ │ ├── NEC_2023**Art300**general_wiring_methods.md
│ │ │ │ │ ├── NEC_2023**Art310**conductors_for_general_wiring.md
│ │ │ │ │ ├── NEC_2023**Art408**switchboards_switchgear_and_panelboards.md
│ │ │ │ │ ├── NEC_2023**Art409**industrial_control_panels.md
│ │ │ │ │ ├── NEC_2023**Art430**motors_motor_circuits_and_controllers.md
│ │ │ │ │ ├── NEC_2023**Art670**industrial_machinery.md
│ │ │ │ │ ├── NEC_2023**Art725**class_1_2_3_control_circuits.md
│ │ │ │ │ ├── NEC_OVERVIEW.md
│ │ │ │ │ └── README.md
│ │ │ │ ├── nfpa79
│ │ │ │ │ ├── \_index.yaml
│ │ │ │ │ ├── GENERATION_SUMMARY.md
│ │ │ │ │ ├── NFPA_OVERVIEW.md
│ │ │ │ │ ├── NFPA79_2024**Ch01**administration.md
│ │ │ │ │ ├── NFPA79_2024**Ch02**definitions.md
│ │ │ │ │ ├── NFPA79_2024**Ch03**general_requirements.md
│ │ │ │ │ ├── NFPA79_2024**Ch04**general_conditions_of_installation.md
│ │ │ │ │ ├── NFPA79_2024**Ch05**disconnecting_means.md
│ │ │ │ │ ├── NFPA79_2024**Ch06**overcurrent_protection.md
│ │ │ │ │ ├── NFPA79_2024**Ch07**protection_against_electric_shock.md
│ │ │ │ │ ├── NFPA79_2024**Ch08**grounding_and_bonding.md
│ │ │ │ │ ├── NFPA79_2024**Ch09**control_circuits_and_control_functions.md
│ │ │ │ │ ├── NFPA79_2024**Ch10**operator_interface_devices.md
│ │ │ │ │ ├── NFPA79_2024**Ch11**control_equipment.md
│ │ │ │ │ ├── NFPA79_2024**Ch12**motors_and_associated_equipment.md
│ │ │ │ │ ├── NFPA79_2024**Ch13**appliances_and_accessories.md
│ │ │ │ │ ├── NFPA79_2024**Ch14**lighting.md
│ │ │ │ │ ├── NFPA79_2024**Ch15**transformers_and_power_supplies.md
│ │ │ │ │ ├── NFPA79_2024**Ch16**wiring_methods.md
│ │ │ │ │ ├── NFPA79_2024**Ch17**cables_and_flexible_cords.md
│ │ │ │ │ ├── NFPA79_2024**Ch18**terminal_blocks_and_connectors.md
│ │ │ │ │ ├── NFPA79_2024**Ch19**marking_and_documentation.md
│ │ │ │ │ ├── NFPA79_2024**Ch20**system_integration.md
│ │ │ │ │ └── README.md
│ │ │ │ ├── README.md
│ │ │ │ ├── standards_applicability.md
│ │ │ │ ├── STANDARDS_MODULES_SUMMARY.md
│ │ │ │ └── ul_508a
│ │ │ │ ├── \_index.yaml
│ │ │ │ ├── GENERATION_SUMMARY.md
│ │ │ │ ├── README.md
│ │ │ │ ├── UL508A_2022**control_circuits_and_devices.md
│ │ │ │ ├── UL508A_2022**enclosures_and_environmental_ratings.md
│ │ │ │ ├── UL508A_2022**general_construction_requirements.md
│ │ │ │ ├── UL508A_2022**grounding_and_bonding.md
│ │ │ │ ├── UL508A_2022**marking_and_documentation.md
│ │ │ │ ├── UL508A_2022**motor_controllers_and_drives.md
│ │ │ │ ├── UL508A_2022**overcurrent_protection.md
│ │ │ │ ├── UL508A_2022**sccr_short_circuit_current_rating.md
│ │ │ │ ├── UL508A_2022**scope_and_application.md
│ │ │ │ ├── UL508A_2022**spacing_creepage_clearance.md
│ │ │ │ ├── UL508A_2022**transformers_and_power_supplies.md
│ │ │ │ ├── UL508A_2022**wiring_methods_and_conductors.md
│ │ │ │ └── UL508A_OVERVIEW.md
│ │ │ ├── training_modules
│ │ │ │ ├── commissioning
│ │ │ │ ├── fundamentals
│ │ │ │ ├── safety
│ │ │ │ └── troubleshooting
│ │ │ └── troubleshooting_engine
│ │ │ ├── analog_io
│ │ │ ├── decision_trees.yaml
│ │ │ ├── digital_io
│ │ │ ├── motion_servo
│ │ │ ├── networks
│ │ │ └── pid_control
│ │ └── old_rag
│ │ ├── \_glossary.md
│ │ ├── \_index.yaml
│ │ ├── \_standards_map.md
│ │ ├── audit_tool
│ │ │ ├── outputs
│ │ │ ├── README.md
│ │ │ └── report_templates
│ │ ├── business_metrics_profit_engine
│ │ │ ├── exports
│ │ │ └── README.md
│ │ ├── commissioning_checklists
│ │ │ ├── checklists
│ │ │ ├── outputs
│ │ │ └── README.md
│ │ ├── design_framework
│ │ │ ├── constraints
│ │ │ ├── design_guides
│ │ │ │ └── 01_panel_design_guide.md
│ │ │ ├── outputs
│ │ │ ├── patterns
│ │ │ │ └── io_templates.yaml
│ │ │ └── README.md
│ │ ├── design_package_generator
│ │ │ ├── kits
│ │ │ │ ├── conveyor_control_kit
│ │ │ │ ├── pump_skid_control_kit
│ │ │ │ └── robotic_cell_control_kit
│ │ │ └── README.md
│ │ ├── ip_library_licensing
│ │ │ ├── export_packages
│ │ │ └── README.md
│ │ ├── knowledge_platform
│ │ │ └── README.md
│ │ ├── retainer_support_engine
│ │ │ ├── outputs
│ │ │ └── README.md
│ │ ├── standards_intelligence
│ │ │ ├── clause_index
│ │ │ │ ├── iso_iec_clause_index.yaml
│ │ │ │ ├── nec_clause_index.yaml
│ │ │ │ ├── nfpa79_clause_index.yaml
│ │ │ │ └── ul508a_clause_index.yaml
│ │ │ ├── ISO_IEC
│ │ │ │ ├── iec_60204_1
│ │ │ │ └── README.md
│ │ │ ├── NEC
│ │ │ ├── NFPA
│ │ │ ├── outputs
│ │ │ │ └── standards_guidance_report.md
│ │ │ ├── rules_engine
│ │ │ │ ├── red_flags.yaml
│ │ │ │ └── rules.yaml
│ │ │ └── UL
│ │ ├── training_cert_builder
│ │ │ ├── assessments
│ │ │ ├── modules
│ │ │ └── README.md
│ │ ├── troubleshooting_decision_engine
│ │ │ ├── decision_trees
│ │ │ ├── outputs
│ │ │ ├── playbooks
│ │ │ └── README.md
│ │ └── ul508a_panel_automation
│ │ ├── outputs
│ │ ├── README.md
│ │ └── ul_documentation_templates
│ ├── old_decision_trees
│ ├── past_audits
│ ├── README.md
│ └── superseded_designs
├── change_management
│ ├── decision_log.md
│ ├── design_change_policy.md
│ ├── promotion_checklist_drafts_to_rag.md
│ ├── README.md
│ └── release_notes.md
├── control-standards
│ ├── design_drafts
│ │ ├── diagrams
│ │ ├── experiments
│ │ ├── README.md
│ │ └── scratch_notes
│ ├── drafts
│ │ ├── copied_standard_text
│ │ ├── raw_notes
│ │ ├── README.md
│ │ └── vendor_docs
│ ├── exports
│ │ ├── docx
│ │ ├── pdf
│ │ ├── README.md
│ │ └── reports
│ ├── QUICK_START.md
│ ├── rag
│ │ ├── commissioning_checklists
│ │ │ ├── dry_run
│ │ │ ├── handover
│ │ │ ├── live_run
│ │ │ └── pre_power
│ │ ├── design_framework
│ │ │ ├── control_system_design
│ │ │ ├── io_architecture
│ │ │ ├── network_architecture
│ │ │ ├── power_distribution
│ │ │ ├── safety_architecture
│ │ │ └── us_eu_compliance_wizard
│ │ ├── MIGRATION_SUMMARY_20260115_221742.md
│ │ ├── RAG_DIRECTORY_STATUS.md
│ │ ├── standards_intelligence
│ │ │ ├── \_glossary.md
│ │ │ ├── \_index.yaml
│ │ │ ├── \_overlap_matrix
│ │ │ │ ├── \_index.yaml
│ │ │ │ ├── file_structure.md
│ │ │ │ ├── nfpa79_iec60204_overlap.md
│ │ │ │ ├── standards_decision_workflow.md
│ │ │ │ ├── standards_overlap.md
│ │ │ │ └── ul508a_nec_nfpa79_overlap.md
│ │ │ ├── \_overlap_notes
│ │ │ │ ├── \_index.yaml
│ │ │ │ ├── file_structure.md
│ │ │ │ ├── GENERATION_STATUS.md
│ │ │ │ └── overlap**sccr.md
│ │ │ ├── \_standards_map.md
│ │ │ ├── COMPLETE_STANDARDS_PORTFOLIO.md
│ │ │ ├── iec_60204_1
│ │ │ │ ├── \_index.yaml
│ │ │ │ ├── GENERATION_SUMMARY.md
│ │ │ │ ├── IEC60204_1_2018**Clause01**scope.md
│ │ │ │ ├── IEC60204_1_2018**Clause02**normative_references.md
│ │ │ │ ├── IEC60204_1_2018**Clause03**terms_and_definitions.md
│ │ │ │ ├── IEC60204_1_2018**Clause04**general_requirements.md
│ │ │ │ ├── IEC60204_1_2018**Clause05**incoming_supply.md
│ │ │ │ ├── IEC60204_1_2018**Clause06**protection_against_electric_shock.md
│ │ │ │ ├── IEC60204_1_2018**Clause07**protection_of_equipment.md
│ │ │ │ ├── IEC60204_1_2018**Clause08**equipotential_bonding.md
│ │ │ │ ├── IEC60204_1_2018**Clause09**control_circuits_and_functions.md
│ │ │ │ ├── IEC60204_1_2018**Clause10**operator_interface.md
│ │ │ │ ├── IEC60204_1_2018**Clause11**control_equipment.md
│ │ │ │ ├── IEC60204_1_2018**Clause12**motors_and_drives.md
│ │ │ │ ├── IEC60204_1_2018**Clause13**accessories_and_lighting.md
│ │ │ │ ├── IEC60204_1_2018**Clause14**marking_and_documentation.md
│ │ │ │ ├── IEC60204_1_2018**Clause15**verification.md
│ │ │ │ ├── IEC60204_OVERVIEW.md
│ │ │ │ └── README.md
│ │ │ ├── iec_61508
│ │ │ ├── iec_61511
│ │ │ ├── iec_62061
│ │ │ ├── iso_12100
│ │ │ ├── iso_13849_1
│ │ │ │ └── file_structure.md
│ │ │ ├── nec
│ │ │ │ ├── \_index.yaml
│ │ │ │ ├── GENERATION_SUMMARY.md
│ │ │ │ ├── NEC_2023**Art110**requirements_for_electrical_installations.md
│ │ │ │ ├── NEC_2023**Art240**overcurrent_protection.md
│ │ │ │ ├── NEC_2023**Art250**grounding_and_bonding.md
│ │ │ │ ├── NEC_2023**Art300**general_wiring_methods.md
│ │ │ │ ├── NEC_2023**Art310**conductors_for_general_wiring.md
│ │ │ │ ├── NEC_2023**Art408**switchboards_switchgear_and_panelboards.md
│ │ │ │ ├── NEC_2023**Art409**industrial_control_panels.md
│ │ │ │ ├── NEC_2023**Art430**motors_motor_circuits_and_controllers.md
│ │ │ │ ├── NEC_2023**Art670**industrial_machinery.md
│ │ │ │ ├── NEC_2023**Art725**class_1_2_3_control_circuits.md
│ │ │ │ ├── NEC_COMPLETION_STATUS.md
│ │ │ │ ├── NEC_OVERVIEW.md
│ │ │ │ └── README.md
│ │ │ ├── nfpa79
│ │ │ │ ├── \_index.yaml
│ │ │ │ ├── GENERATION_SUMMARY.md
│ │ │ │ ├── NFPA_OVERVIEW.md
│ │ │ │ ├── NFPA79_2024**Ch01**administration.md
│ │ │ │ ├── NFPA79_2024**Ch02**definitions.md
│ │ │ │ ├── NFPA79_2024**Ch03**general_requirements.md
│ │ │ │ ├── NFPA79_2024**Ch04**general_conditions_of_installation.md
│ │ │ │ ├── NFPA79_2024**Ch05**disconnecting_means.md
│ │ │ │ ├── NFPA79_2024**Ch06**overcurrent_protection.md
│ │ │ │ ├── NFPA79_2024**Ch07**protection_against_electric_shock.md
│ │ │ │ ├── NFPA79_2024**Ch08**grounding_and_bonding.md
│ │ │ │ ├── NFPA79_2024**Ch09**control_circuits_and_control_functions.md
│ │ │ │ ├── NFPA79_2024**Ch10**operator_interface_devices.md
│ │ │ │ ├── NFPA79_2024**Ch11**control_equipment.md
│ │ │ │ ├── NFPA79_2024**Ch12**motors_and_associated_equipment.md
│ │ │ │ ├── NFPA79_2024**Ch13**appliances_and_accessories.md
│ │ │ │ ├── NFPA79_2024**Ch14**lighting.md
│ │ │ │ ├── NFPA79_2024**Ch15**transformers_and_power_supplies.md
│ │ │ │ ├── NFPA79_2024**Ch16**wiring_methods.md
│ │ │ │ ├── NFPA79_2024**Ch17**cables_and_flexible_cords.md
│ │ │ │ ├── NFPA79_2024**Ch18**terminal_blocks_and_connectors.md
│ │ │ │ ├── NFPA79_2024**Ch19**marking_and_documentation.md
│ │ │ │ ├── NFPA79_2024**Ch20**system_integration.md
│ │ │ │ └── README.md
│ │ │ ├── README.md
│ │ │ ├── standards_applicability.md
│ │ │ ├── STANDARDS_COMPLETION_STATUS.md
│ │ │ ├── STANDARDS_MODULES_SUMMARY.md
│ │ │ └── ul_508a
│ │ │ ├── \_index.yaml
│ │ │ ├── GENERATION_SUMMARY.md
│ │ │ ├── README.md
│ │ │ ├── UL508A_2022**control_circuits_and_devices.md
│ │ │ ├── UL508A_2022**enclosures_and_environmental_ratings.md
│ │ │ ├── UL508A_2022**general_construction_requirements.md
│ │ │ ├── UL508A_2022**grounding_and_bonding.md
│ │ │ ├── UL508A_2022**marking_and_documentation.md
│ │ │ ├── UL508A_2022**motor_controllers_and_drives.md
│ │ │ ├── UL508A_2022**overcurrent_protection.md
│ │ │ ├── UL508A_2022**sccr_short_circuit_current_rating.md
│ │ │ ├── UL508A_2022**scope_and_application.md
│ │ │ ├── UL508A_2022**spacing_creepage_clearance.md
│ │ │ ├── UL508A_2022**transformers_and_power_supplies.md
│ │ │ ├── UL508A_2022**wiring_methods_and_conductors.md
│ │ │ └── UL508A_OVERVIEW.md
│ │ ├── training_modules
│ │ │ ├── commissioning
│ │ │ ├── fundamentals
│ │ │ ├── safety
│ │ │ └── troubleshooting
│ │ └── troubleshooting_engine
│ │ ├── analog_io
│ │ ├── decision_trees.yaml
│ │ ├── digital_io
│ │ ├── motion_servo
│ │ ├── networks
│ │ └── pid_control
│ ├── README.md
│ ├── STRUCTURE_SUMMARY.md
│ └── tools
│ ├── audit_tool
│ │ ├── outputs
│ │ ├── README.md
│ │ └── report_templates
│ ├── business_metrics_profit_engine
│ │ ├── exports
│ │ └── README.md
│ ├── design_package_generator
│ │ ├── kits
│ │ │ ├── conveyor_control_kit
│ │ │ ├── pump_skid_control_kit
│ │ │ └── robotic_cell_control_kit
│ │ └── README.md
│ ├── ip_library_licensing
│ │ ├── export_packages
│ │ └── README.md
│ ├── knowledge_platform
│ │ └── README.md
│ ├── retainer_support_engine
│ │ ├── outputs
│ │ └── README.md
│ └── ul508a_panel_automation
│ ├── outputs
│ ├── README.md
│ └── ul_documentation_templates
├── data
│ ├── historian_exports
│ ├── network_captures
│ ├── plc_exports
│ └── README.md
├── drafts
│ ├── 00_inbox_notes.md
│ ├── commissioning_notes
│ ├── design_working
│ ├── experiments
│ ├── README.md
│ ├── standards_notes
│ └── troubleshooting_logs
├── drafts_DO_NOT_READ
│ ├── control_system_project_template.tar.gz
│ ├── DELIVERABLE.md
│ ├── PROJECT_STRUCTURE 4.59.29 PM.md
│ ├── QUICK_START.md
│ └── README.md
├── exports
│ ├── csv
│ ├── pdf
│ ├── README.md
│ └── snapshots
├── main.py
├── MIGRATION_GUIDE.md
├── MIGRATION_READY.md
├── MIGRATION_SCRIPT.sh
├── PRE_MIGRATION_CHECK.sh
├── pyproject.toml
├── rag -> /Users/kyawminthu/Dev/tools/control-standards/rag
├── README.md
├── STRUCTURE_SUMMARY.md
├── templates
│ ├── checklists
│ ├── design_guides
│ ├── md_headers
│ │ ├── draft_only_header.md
│ │ └── rag_approved_header.md
│ ├── README.md
│ └── reports
└── tools
└── README.md
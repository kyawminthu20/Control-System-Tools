# EXPORTS - CLIENT AND AUDIT OUTPUT

**AI_READ_ACCESS: READ_ONLY**
**CONTENT_CLASS: GENERATED_OUTPUT**

## Purpose

This directory contains **generated deliverables** for:
1. Client documentation packages
2. Audit and compliance reports
3. Training materials
4. Design review packages

## Subdirectories

### `/pdf/` - PDF Exports
Generated PDF documents for client delivery:
- Design packages
- Compliance reports
- Training manuals
- Commissioning checklists
- Audit reports

**FORMAT**: PDF (read-only, professional formatting)

### `/docx/` - Editable Documents
Microsoft Word documents for collaborative editing:
- Design specifications
- Project documentation
- Training materials requiring client input
- Templates for client use

**FORMAT**: DOCX (editable by clients)

### `/reports/` - Automated Reports
Generated compliance and audit reports:
- Standards compliance scorecards
- Design verification reports
- Commissioning test results
- Safety audit findings
- SCCR calculation reports

**FORMAT**: PDF, XLSX, or HTML

## File Naming Convention

Use consistent naming for traceability:

```
[Date]_[ClientName]_[DocumentType]_[Version].ext

Examples:
2026-01-15_AcmeMfg_ControlPanelDesign_v1.0.pdf
2026-01-15_AcmeMfg_UL508A_Compliance_Report_v1.0.pdf
2026-01-15_AcmeMfg_Commissioning_Checklist_Final.docx
```

## Generation Sources

Documents in `/exports/` are generated from:

**From `/rag/` (primary source)**:
- Standards intelligence → Compliance reports
- Design framework → Design templates
- Commissioning checklists → Commissioning packages
- Training modules → Training manuals

**From `/design_drafts/` (project-specific)**:
- Project design work → Design packages
- Calculations and analysis → Engineering reports

## Document Types

### 1. Design Packages
**Location**: `/exports/pdf/design_packages/`

**Contents**:
- Single-line diagrams
- Control panel layouts
- Bill of materials
- Wire schedules
- Standards compliance summary
- Design calculations

**Source**: `/rag/design_framework/` + project-specific work from `/design_drafts/`

### 2. Compliance Reports
**Location**: `/exports/pdf/compliance_reports/`

**Contents**:
- Standards checklist (UL 508A, NEC, NFPA 79, IEC 60204-1)
- Gap analysis
- Compliance scoring
- Corrective action recommendations

**Source**: `/rag/standards_intelligence/` automated analysis

### 3. Commissioning Packages
**Location**: `/exports/pdf/commissioning_packages/`

**Contents**:
- Pre-power checklists
- Dry run procedures
- Live run test protocols
- Handover documentation
- As-built documentation

**Source**: `/rag/commissioning_checklists/`

### 4. Training Materials
**Location**: `/exports/pdf/training_materials/`

**Contents**:
- Training manuals
- Quick reference guides
- Troubleshooting guides
- Safety procedures

**Source**: `/rag/training_modules/`

### 5. Audit Reports
**Location**: `/exports/reports/audit_reports/`

**Contents**:
- Standards compliance audit
- Safety system verification
- Documentation review
- Findings and recommendations

**Source**: `/rag/standards_intelligence/` automated scoring

## Generation Workflow

### Manual Generation
1. Develop content in `/rag/` or `/design_drafts/`
2. Use templates from `/rag/design_framework/`
3. Export to PDF or DOCX
4. Save to appropriate `/exports/` subdirectory
5. Deliver to client

### Automated Generation
1. Run automated tool (e.g., SCCR calculator, compliance checker)
2. Tool reads from `/rag/standards_intelligence/`
3. Tool generates report
4. Report auto-saved to `/exports/reports/`
5. Review and deliver

## Quality Control

Before client delivery:

**Technical Review**:
- [ ] All technical content verified
- [ ] Calculations checked
- [ ] Standards references accurate
- [ ] No copyrighted standard text (paraphrased only)

**Formatting Review**:
- [ ] Professional formatting
- [ ] Company branding applied
- [ ] Table of contents accurate
- [ ] Page numbers correct
- [ ] Version number clear

**Compliance Review**:
- [ ] Client requirements met
- [ ] Standards compliance documented
- [ ] Safety considerations addressed
- [ ] Liability disclaimers included

## Version Control

Use semantic versioning:
- **v1.0** - Initial client delivery
- **v1.1** - Minor revisions/corrections
- **v2.0** - Major revision or new design iteration

Archive previous versions:
```
/exports/pdf/archive/2026-01-15_AcmeMfg_ControlPanelDesign_v1.0.pdf
/exports/pdf/2026-01-20_AcmeMfg_ControlPanelDesign_v1.1.pdf (current)
```

## AI Access Guidelines

**AI READ_ONLY Access**:
- AI can read generated documents to answer client questions
- AI can reference prior designs for pattern recognition
- AI should NOT modify files in `/exports/`

**When AI References Exports**:
> "Note: Referenced from /exports/ (client deliverable). This is a specific project design, not a general pattern."

## Client Collaboration

### Editable Documents (`/exports/docx/`)
When client needs to edit:
1. Provide DOCX version for collaboration
2. Track changes enabled
3. Version number in filename
4. Request final approval before generating PDF

### Read-Only Documents (`/exports/pdf/`)
For final deliverables:
1. Generate PDF from approved DOCX or from `/rag/` templates
2. Watermark if draft
3. Digital signature for final
4. Archive previous versions

## Integration with Other Tools

### Design Package Generator
**Input**: Design from `/rag/design_framework/` + project specifics
**Output**: `/exports/pdf/design_packages/[project]_design_v1.0.pdf`

### UL 508A Compliance Checker
**Input**: Panel design + `/rag/standards_intelligence/ul_508a/`
**Output**: `/exports/reports/[project]_UL508A_compliance_report.pdf`

### Commissioning Checklist Generator
**Input**: `/rag/commissioning_checklists/` + project specifics
**Output**: `/exports/pdf/commissioning_packages/[project]_commissioning.pdf`

### SCCR Calculator
**Input**: BOM + component ratings
**Output**: `/exports/reports/[project]_SCCR_calculation.pdf`

## Security and Confidentiality

**Client-Proprietary Information**:
- Client project files stay in `/exports/` (not in `/rag/`)
- Generic patterns go to `/rag/design_framework/`
- Remove client-specific info before creating patterns

**File Retention**:
- Keep client deliverables for 7 years (regulatory requirement)
- Archive annually
- Purge per retention policy

## Templates

Standard templates stored in:
- `/rag/design_framework/` - Design templates
- `/rag/commissioning_checklists/` - Commissioning templates
- `/rag/training_modules/` - Training templates

Templates should be:
- Company-branded
- Standards-compliant
- Professionally formatted
- Easy to customize

## Common Automated Reports

### 1. UL 508A Compliance Scorecard
**Generator**: UL 508A audit tool
**Source Data**: `/rag/standards_intelligence/ul_508a/`
**Output**: PDF scorecard with pass/fail/NA for each section

### 2. SCCR Calculation Report
**Generator**: SCCR calculator
**Source Data**: BOM + component SCCR ratings
**Output**: PDF showing weakest-link calculation and final SCCR

### 3. Dual Compliance Report (US + EU)
**Generator**: Dual compliance checker
**Source Data**: `/rag/standards_intelligence/nfpa79/` + `/iec_60204_1/`
**Output**: Side-by-side comparison showing compliance with both standards

### 4. Commissioning Test Results
**Generator**: Commissioning tracking tool
**Source Data**: `/rag/commissioning_checklists/` + test results
**Output**: PDF with pass/fail results and as-built documentation

## Delivery Methods

**Email**:
- PDF attachments for small documents
- Version number in filename

**Cloud Storage**:
- Large packages (>10MB)
- Shared folders for collaboration
- Access control per project

**Physical**:
- Printed and bound for formal deliveries
- USB drive for comprehensive packages

---

**REMEMBER**: Files in `/exports/` represent your professional reputation. Always review before client delivery. Ensure accuracy, professionalism, and compliance.

**Last Updated**: 2026-01-15

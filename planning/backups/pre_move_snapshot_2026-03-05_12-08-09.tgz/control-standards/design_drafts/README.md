# DESIGN DRAFTS - HUMAN THINKING SPACE

**AI_READ_ACCESS: ALLOWED (with caution)**
**CONTENT_CLASS: WORK_IN_PROGRESS**

## Purpose

This directory is a **working space** for:
1. Active design work and brainstorming
2. Experiments and proof-of-concepts
3. Work-in-progress diagrams and schematics
4. Design notes before formal documentation

## Subdirectories

### `/scratch_notes/`
Quick notes, brainstorming, and rough ideas:
- Design concepts
- Calculation scratch work
- Meeting notes
- TODO lists
- Brainstorming sessions

**STATUS**: Work in progress, may contain errors

### `/experiments/`
Proof-of-concept designs and testing:
- Alternative design approaches
- Component testing results
- Concept validation
- Performance experiments

**STATUS**: Experimental, not production-ready

### `/diagrams/`
Work-in-progress schematics and drawings:
- Draft electrical schematics
- Control logic diagrams
- Network topologies
- Panel layouts

**STATUS**: Draft quality, subject to revision

## Workflow

### Working in `/design_drafts/`

1. **Start here** for new design work
2. **Experiment freely** - this is safe space for iteration
3. **Reference** `/rag/` for standards and patterns
4. **Document** key decisions and rationale
5. **Promote** completed work to `/rag/design_framework/` when ready

### Promotion to `/rag/`

When design is complete and verified:

1. **Review** for accuracy and completeness
2. **Verify** standards compliance
3. **Add** metadata headers (CONTENT_CLASS: RAG_APPROVED)
4. **Format** according to `/rag/` structure
5. **Move** to appropriate `/rag/` subdirectory:
   - Design patterns → `/rag/design_framework/`
   - Troubleshooting guides → `/rag/troubleshooting_engine/`
   - Procedures → `/rag/commissioning_checklists/`
   - Training content → `/rag/training_modules/`

### Example Workflow

**Initial Design (in `/design_drafts/scratch_notes/`)**:
```
Project: Robot Cell Power Distribution
Date: 2026-01-15

Ideas:
- Main disconnect: 200A, 480V
- Branch circuits for robot (80A), conveyor (30A), lighting (20A)
- Control transformer 480V → 120V, 5kVA
- Need to check NFPA 79 Chapter 5 for disconnect requirements
- TODO: Calculate wire sizes per NEC Article 310
```

**Refined Design (in `/design_drafts/experiments/`)**:
- Detailed calculations
- Component selection
- Vendor quote comparisons
- Risk analysis

**Final Pattern (promoted to `/rag/design_framework/power_distribution/`)**:
- Standardized design template
- Standards references
- Design checklist
- Bill of materials template

## AI Access Guidelines

### AI CAN Read:
- ✅ Completed design notes with clear conclusions
- ✅ Experimental results with analysis
- ✅ Design decisions with rationale
- ✅ Verified calculations

### AI SHOULD AVOID:
- ⚠️ Incomplete thoughts and brainstorms
- ⚠️ Contradictory or conflicting notes
- ⚠️ Unverified claims
- ⚠️ Personal opinions without technical basis

### AI MUST Indicate:
When reading from `/design_drafts/`, AI should note:
> "Note: This content is from design_drafts (work-in-progress). Verify before using in production designs."

## File Naming

Use descriptive names with dates:

- `2026-01-15_robot_cell_power_calc.md` - Good
- `power.md` - Too generic
- `DRAFT_conveyor_control_logic_v3.md` - Good (indicates version)

## Version Control

Since this is active working space:
- Commit frequently to track iterations
- Use descriptive commit messages
- Tag major milestones
- Branch for major experiments

## Integration with Other Directories

### Reference `/rag/` for:
- Standards requirements → `/rag/standards_intelligence/`
- Proven design patterns → `/rag/design_framework/`
- Troubleshooting context → `/rag/troubleshooting_engine/`

### Reference `/drafts/` for:
- Standard text verification → `/drafts/copied_standard_text/` (human only)
- Vendor specifications → `/drafts/vendor_docs/`

### Export to `/exports/` when:
- Client deliverable is ready
- Audit documentation needed
- Training materials finalized

## Quality Gates

Before promoting to `/rag/`:

**Technical Review**:
- [ ] Design is complete and verified
- [ ] Calculations are checked
- [ ] Standards compliance verified
- [ ] Safety considerations documented

**Content Review**:
- [ ] Clear and concise writing
- [ ] No copyrighted verbatim text
- [ ] Proper citations and references
- [ ] Metadata headers complete

**Peer Review**:
- [ ] Technical review by qualified engineer
- [ ] Standards compliance check
- [ ] Readability review

## Common Use Cases

### 1. New Control Panel Design
**Location**: `/design_drafts/experiments/panel_design_project_x/`
- Sketch initial concepts
- Calculate loads and wire sizes
- Select components
- Verify against UL 508A and NEC Article 409
- Promote final design to `/rag/design_framework/control_system_design/`

### 2. Troubleshooting Documentation
**Location**: `/design_drafts/scratch_notes/troubleshooting_notes/`
- Document observed failure modes
- Build diagnostic decision tree
- Test diagnostic procedures
- Promote to `/rag/troubleshooting_engine/`

### 3. Standards Research
**Location**: `/design_drafts/scratch_notes/standards_research/`
- Compare requirements across standards
- Document interpretations
- Build compliance matrices
- Promote to `/rag/standards_intelligence/_overlap_notes/`

## Cleanup Policy

**Monthly Review**:
- Archive completed designs (moved to `/rag/`)
- Delete obsolete experiments
- Consolidate redundant notes
- Update indexes

**Annual Purge**:
- Remove experiments that didn't pan out
- Archive old project notes
- Clear scratch notes older than 2 years

## Tips for Effective Use

1. **Date everything** - Helps track evolution of ideas
2. **Cross-reference** - Link to standards and patterns
3. **Document assumptions** - Future you will thank you
4. **Capture alternatives** - Document why you chose option A over B
5. **Note open questions** - Track what needs research
6. **Be messy here** - Perfect is the enemy of done in this space

## Protection and Security

While AI can read this directory:
- No client-proprietary information (use separate client repos)
- No passwords or credentials
- No personally identifiable information (PII)
- No export-controlled information

---

**REMEMBER**: This is your thinking space. Be creative, experiment freely, and promote the good stuff to `/rag/` when it's ready for production use.

**Last Updated**: 2026-01-15

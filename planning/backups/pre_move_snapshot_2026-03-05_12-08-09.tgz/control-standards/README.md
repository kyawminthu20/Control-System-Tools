# Control Standards Intelligence Repository
**Version:** 1.0
**Created:** 2026-01-15
**Purpose:** Comprehensive knowledge base for industrial control system design, compliance, and troubleshooting

## Repository Structure

This repository uses a **four-tier architecture** for knowledge governance:

### 🟢 `/rag/` - AI-READABLE Authoritative Knowledge
**AI_READ_ACCESS: ALLOWED**
Contains verified, production-ready content for AI indexing and retrieval.

#### Standards Intelligence
- **nec/** - National Electrical Code (2023)
- **nfpa79/** - NFPA 79 Electrical Standard for Industrial Machinery (2024)
- **ul_508a/** - UL 508A Industrial Control Panels (2022)
- **iec_60204_1/** - IEC 60204-1 Electrical Equipment of Machines (2018)
- **iso_13849_1/** - ISO 13849-1 Safety of Machinery - Control Systems (2023)
- **iso_12100/** - ISO 12100 Risk Assessment (2010)
- **iec_62061/** - IEC 62061 Functional Safety (2021)
- **iec_61508/** - IEC 61508 Functional Safety Foundation (2010)
- **iec_61511/** - IEC 61511 Process Industry Safety (2016)
- **_overlap_matrix/** - Cross-standard requirement mappings
- **_overlap_notes/** - Detailed comparison documentation

#### Design Framework
- **control_system_design/** - PLC/PAC architecture patterns
- **safety_architecture/** - Safety-rated control design (PL, SIL)
- **io_architecture/** - I/O system design patterns
- **network_architecture/** - Industrial network topologies
- **power_distribution/** - Panel power design
- **us_eu_compliance_wizard/** - Dual US/EU compliance tools

#### Troubleshooting Engine
- **digital_io/** - Digital I/O fault diagnosis
- **analog_io/** - Analog signal troubleshooting
- **networks/** - Industrial network diagnostics
- **motion_servo/** - Motion control troubleshooting
- **pid_control/** - PID loop tuning and diagnostics
- **decision_trees.yaml** - Diagnostic decision tree index

#### Commissioning Checklists
- **pre_power/** - Pre-energization verification
- **dry_run/** - De-energized functional testing
- **live_run/** - Energized commissioning
- **handover/** - Customer handover procedures

#### Training Modules
- **fundamentals/** - Control system basics
- **safety/** - Safety system design and verification
- **commissioning/** - Commissioning procedures
- **troubleshooting/** - Diagnostic methodologies

### 🔵 `/design_drafts/` - HUMAN THINKING SPACE
**AI_READ_ACCESS: ALLOWED (with caution)**
Working area for in-progress designs and experiments.

- **scratch_notes/** - Quick notes and brainstorming
- **experiments/** - Proof-of-concept designs
- **diagrams/** - Work-in-progress schematics

### 🔴 `/drafts/` - ABSOLUTE NO-AI ZONE
**AI_READ_ACCESS: FORBIDDEN**
Contains copyrighted material and unverified raw content.

- **copied_standard_text/** - NEVER indexed - copyrighted standard text
- **raw_notes/** - Unverified notes and references
- **vendor_docs/** - Vendor-provided documentation

### 🟡 `/exports/` - CLIENT AND AUDIT OUTPUT
**AI_READ_ACCESS: READ_ONLY**
Generated deliverables for clients and audits.

- **pdf/** - PDF exports for clients
- **docx/** - Editable Word documents
- **reports/** - Compliance and audit reports

## Usage Guidelines

### For AI Systems
1. **READ** from `/rag/` only - all content is RAG_APPROVED
2. **NEVER READ** from `/drafts/` - contains copyrighted material
3. **READ CAUTIOUSLY** from `/design_drafts/` - work in progress
4. **READ ONLY** from `/exports/` - generated output

### For Humans
1. **Develop content** in `/design_drafts/` or `/drafts/`
2. **Promote to `/rag/`** only after verification and copyright compliance
3. **Export deliverables** to `/exports/` for client use
4. **Keep copyrighted text** strictly in `/drafts/copied_standard_text/`

## Content Governance

### RAG Approval Process
1. Content created in `/design_drafts/` or `/drafts/`
2. Verify copyright compliance (no verbatim standard text)
3. Add metadata headers (CONTENT_CLASS, AI_READ_ACCESS, STATUS)
4. Move to `/rag/` and update relevant `_index.yaml`
5. Mark STATUS: APPROVED in metadata

### Copyright Compliance
- **NEVER** include verbatim text from copyrighted standards
- **ONLY** paraphrase intent, guidance, and interpretation
- **ALWAYS** encourage purchase of official standards
- **KEEP** any copied standard text in `/drafts/copied_standard_text/` (FORBIDDEN to AI)

## Standards Coverage

| Standard | Edition | Jurisdiction | Elements | Status |
|----------|---------|--------------|----------|--------|
| NEC | 2023 | US | 10 articles | ✅ Complete |
| NFPA 79 | 2024 | US | 20 chapters | ✅ Complete |
| UL 508A | 2022 | US | 11 sections | ✅ Complete |
| IEC 60204-1 | 2018 | Global | 15 clauses | ✅ Complete |
| ISO 13849-1 | 2023 | Global | TBD | 🔄 Planned |
| ISO 12100 | 2010 | Global | TBD | 🔄 Planned |
| IEC 62061 | 2021 | Global | TBD | 🔄 Planned |
| IEC 61508 | 2010 | Global | TBD | 🔄 Planned |
| IEC 61511 | 2016 | Global | TBD | 🔄 Planned |

## Cross-Standard Integration

### US Standards Relationships
```
NEC Article 409 ←→ UL 508A ←→ NFPA 79 Ch 11
    ↓                ↓              ↓
Panel Code      Panel Design   Machinery Control
```

### US ↔ International Equivalents
```
NFPA 79 (US)  ←→  IEC 60204-1 (Global)
   Ch 5              Clause 5 (Incoming Supply)
   Ch 8              Clause 8 (Bonding)
   Ch 9              Clause 9 (Control Circuits)
```

### Safety Standards Integration
```
For International:
ISO 12100 (Risk Assessment)
    ↓
ISO 13849-1 OR IEC 62061 (Safety Functions)
    ↓
IEC 60204-1 (Electrical Implementation)
```

## Automation Tools

### Implemented
- Standards intelligence indexing and routing
- Cross-reference mapping system

### Planned
- SCCR calculator (UL 508A Section SB)
- Wire sizing automation (NEC Article 310, UL 508A Section 5)
- Spacing validation (UL 508A Section 4)
- Dual-compliance checker (IEC + NFPA)
- CE marking documentation generator
- Regional adaptation wizard (US ↔ EU)

## Development Workflow

### Adding New Standard Content
1. Create folder in `/rag/standards_intelligence/<standard_name>/`
2. Create `_index.yaml` with document registry
3. Generate chapter/article/clause files with templates
4. Fill content (copyright compliant, paraphrased only)
5. Create `OVERVIEW.md` and `GENERATION_SUMMARY.md`
6. Update this README with new standard

### Adding Design Framework Modules
1. Create folder in `/rag/design_framework/<module_name>/`
2. Create design pattern documents
3. Link to relevant standards
4. Add examples and decision trees

### Adding Troubleshooting Content
1. Create folder in `/rag/troubleshooting_engine/<system>/`
2. Build decision trees for fault diagnosis
3. Link to relevant standards and design patterns
4. Add symptom → root cause → solution mappings

## Business Applications

### Tools Enabled by This Repository
1. Standards Intelligence - RAG-powered standards navigation
2. Design Framework - Standards-based design patterns
3. Troubleshooting Decision Engine - Fault diagnosis
4. Commissioning Checklists - Standards verification
5. Audit Tool - Compliance scoring
6. Design Package Generator - Standards-compliant designs
7. Retainer Support Engine - Standards update tracking
8. Knowledge Platform - Standards navigation
9. UL 508A Panel Automation - Automated UL compliance
10. Training & Certification Builder - Standards training
11. IP Library & Licensing - Standards-based IP
12. Business Metrics - Compliance metrics

## Getting Started

### For Standards Intelligence
1. Navigate to `/rag/standards_intelligence/`
2. Choose US standards (nec, nfpa79, ul_508a) or International (iec_60204_1)
3. Read `OVERVIEW.md` in each folder
4. Use `_index.yaml` for RAG routing

### For Design Work
1. Start in `/design_drafts/` for brainstorming
2. Reference `/rag/design_framework/` for patterns
3. Check `/rag/standards_intelligence/` for compliance
4. Export deliverables to `/exports/`

### For Troubleshooting
1. Navigate to `/rag/troubleshooting_engine/<system>/`
2. Follow decision trees from symptom to root cause
3. Reference standards for compliance verification

## Changelog

- 2026-01-15 — Repository structure created
  - Four-tier architecture established
  - Standards intelligence folders created
  - Design framework folders created
  - Troubleshooting engine folders created
  - Commissioning and training folders created
  - Governance and copyright policies documented

---

**Copyright Compliance Notice**: This repository contains NO copyrighted standard text. All content is paraphrased guidance and interpretation. Always purchase official standards from NFPA, IEC, ISO, and UL for authoritative reference.

**Business Value**: Enables 12 distinct AI-powered tools for industrial control system design, compliance, troubleshooting, and training across US and international markets.

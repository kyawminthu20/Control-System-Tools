# Control Standards Repository - Structure Summary
**Created:** 2026-01-15
**Status:** ✅ Complete Structure Ready for Content

## Repository Overview

Complete **four-tier architecture** for industrial control system intelligence:
- **49 directories** organized by function and access control
- **4 main tiers**: `/rag/`, `/design_drafts/`, `/drafts/`, `/exports/`
- **9 standards modules** (4 complete, 5 planned)
- **6 design framework modules**
- **5 troubleshooting categories**
- **4 commissioning phases**
- **4 training modules**

## Directory Tree

```
control-standards/
├── README.md                          # Main repository documentation
├── STRUCTURE_SUMMARY.md              # This file
│
├── rag/                              # 🟢 AI-READABLE (governed)
│   ├── standards_intelligence/       # Standards knowledge base
│   │   ├── _index.yaml              # Master routing index
│   │   ├── _overlap_matrix/         # Cross-standard mappings
│   │   ├── _overlap_notes/          # Detailed comparisons
│   │   ├── nec/                     # ✅ NEC 2023 (10 articles)
│   │   ├── nfpa79/                  # ✅ NFPA 79 2024 (20 chapters)
│   │   ├── ul_508a/                 # ✅ UL 508A 2022 (11 sections)
│   │   ├── iec_60204_1/             # ✅ IEC 60204-1 2018 (15 clauses)
│   │   ├── iso_13849_1/             # 🔄 ISO 13849-1 2023 (planned)
│   │   ├── iso_12100/               # 🔄 ISO 12100 2010 (planned)
│   │   ├── iec_62061/               # 🔄 IEC 62061 2021 (planned)
│   │   ├── iec_61508/               # 🔄 IEC 61508 2010 (planned)
│   │   └── iec_61511/               # 🔄 IEC 61511 2016 (planned)
│   │
│   ├── design_framework/             # Design patterns and architectures
│   │   ├── control_system_design/   # PLC/PAC architecture
│   │   ├── safety_architecture/     # Safety system design (PL/SIL)
│   │   ├── io_architecture/         # I/O system patterns
│   │   ├── network_architecture/    # Industrial network topologies
│   │   ├── power_distribution/      # Panel power design
│   │   └── us_eu_compliance_wizard/ # Dual US/EU compliance
│   │
│   ├── troubleshooting_engine/       # Diagnostic decision trees
│   │   ├── decision_trees.yaml      # Master index
│   │   ├── digital_io/              # Digital I/O diagnostics
│   │   ├── analog_io/               # Analog signal troubleshooting
│   │   ├── networks/                # Network communications
│   │   ├── motion_servo/            # Motion control diagnostics
│   │   └── pid_control/             # PID loop tuning
│   │
│   ├── commissioning_checklists/     # Standards verification
│   │   ├── pre_power/               # Pre-energization checks
│   │   ├── dry_run/                 # De-energized functional test
│   │   ├── live_run/                # Energized commissioning
│   │   └── handover/                # Customer handover
│   │
│   └── training_modules/             # Training and certification
│       ├── fundamentals/             # Control system basics
│       ├── safety/                   # Safety system training
│       ├── commissioning/            # Commissioning procedures
│       └── troubleshooting/          # Diagnostic training
│
├── design_drafts/                    # 🔵 HUMAN THINKING SPACE
│   ├── README.md                     # Usage guidelines
│   ├── scratch_notes/                # Quick notes, brainstorming
│   ├── experiments/                  # Proof-of-concept designs
│   └── diagrams/                     # Work-in-progress schematics
│
├── drafts/                           # 🔴 ABSOLUTE NO-AI ZONE
│   ├── README.md                     # Copyright compliance rules
│   ├── copied_standard_text/         # NEVER indexed - copyrighted text
│   ├── raw_notes/                    # Unverified notes
│   └── vendor_docs/                  # Proprietary vendor material
│
└── exports/                          # 🟡 CLIENT AND AUDIT OUTPUT
    ├── README.md                     # Export guidelines
    ├── pdf/                          # PDF deliverables
    ├── docx/                         # Editable documents
    └── reports/                      # Automated reports
```

## Content Status Summary

### ✅ Complete (Ready for Content Development)

**Standards Intelligence** (4 modules, 56 elements):
- **NEC 2023**: 10 articles covering control panel requirements
- **NFPA 79 2024**: 20 chapters for industrial machinery
- **UL 508A 2022**: 11 sections for industrial control panels
- **IEC 60204-1 2018**: 15 clauses for global machinery

All complete modules are located in:
- `/Users/kyawminthu/Dev/tools/rag/standards_intelligence/`

**Structure** (49 directories):
- All folders created and ready
- Governance README files in place
- Master index files created

### 🔄 Planned (Next Phase)

**Standards Intelligence** (5 modules):
- **ISO 13849-1 2023**: Safety control systems (Performance Levels)
- **ISO 12100 2010**: Risk assessment foundation
- **IEC 62061 2021**: Functional safety (SIL)
- **IEC 61508 2010**: Functional safety foundation
- **IEC 61511 2016**: Process industry safety

**Design Framework** (6 modules):
- Control system design patterns
- Safety architecture templates
- I/O architecture patterns
- Network architecture topologies
- Power distribution templates
- US/EU compliance wizard

**Troubleshooting Engine** (5 categories):
- Digital I/O diagnostics
- Analog I/O diagnostics
- Network troubleshooting
- Motion/servo diagnostics
- PID control tuning

**Commissioning Checklists** (4 phases):
- Pre-power verification
- Dry run procedures
- Live run protocols
- Handover documentation

**Training Modules** (4 areas):
- Fundamentals training
- Safety training
- Commissioning training
- Troubleshooting training

## Access Control Matrix

| Directory | AI Read | AI Write | Human Read | Human Write | Purpose |
|-----------|---------|----------|------------|-------------|---------|
| `/rag/` | ✅ YES | ❌ NO | ✅ YES | ✅ YES | Authoritative AI-readable knowledge |
| `/design_drafts/` | ⚠️ CAUTION | ❌ NO | ✅ YES | ✅ YES | Working space for design |
| `/drafts/` | ❌ FORBIDDEN | ❌ NO | ✅ YES | ✅ YES | Copyrighted material, raw notes |
| `/exports/` | 👁️ READ-ONLY | ❌ NO | ✅ YES | ✅ YES | Client deliverables |

## Key Features

### 1. Copyright Compliance
- **NO copyrighted text** in `/rag/` (AI-readable)
- **ALL copyrighted text** in `/drafts/` (AI-forbidden)
- **Paraphrased guidance only** in RAG-approved content
- **Clear governance** and audit trails

### 2. Standards Coverage
- **US Markets**: NEC, NFPA 79, UL 508A (complete)
- **International Markets**: IEC 60204-1 (complete), ISO 13849-1, IEC 62061 (planned)
- **Safety Standards**: ISO 12100, ISO 13849-1, IEC 62061, IEC 61508, IEC 61511 (planned)
- **Cross-references**: Direct mappings between US and international equivalents

### 3. Design Tools Integration
- Standards intelligence routing
- Design pattern templates
- Troubleshooting decision trees
- Commissioning verification checklists
- Automated compliance tools

### 4. Quality Governance
- Metadata headers on all files
- Embedded changelogs
- Priority classification (CRITICAL, HIGH, Standard)
- Status tracking (DRAFT, REVIEWED, APPROVED)
- Version control

## Metadata Standards

All RAG-approved content includes:

```markdown
<!--
CONTENT_CLASS: RAG_APPROVED
AI_READ_ACCESS: ALLOWED
STATUS: DRAFT | REVIEWED | APPROVED

STANDARD_FAMILY: NEC | NFPA | UL | IEC | ISO
STANDARD_ID: [Standard identifier]
EDITION: [Year]

HIERARCHY:
  [chapter/article/section/clause]: "[number]"
  [chapter_title/etc]: "[Title]"

INDEX_TAGS:
  topics: [keyword, keyword, ...]
  systems: [system_type, ...]
  risks: [risk_type, ...]
-->
```

## Cross-Reference Integration

### US Standards Relationships
```
NEC Article 409 ←→ UL 508A (all sections) ←→ NFPA 79 Ch 11
    ↓                      ↓                        ↓
Panel Code         Panel Design            Machinery Control
```

### US ↔ International Equivalents
```
NFPA 79 (US)       IEC 60204-1 (Global)
Ch 5         ←→    Clause 5 (Incoming Supply)
Ch 8         ←→    Clause 8 (Equipotential Bonding)
Ch 9         ←→    Clause 9 (Control Circuits)
Ch 11        ←→    Clause 11 (Control Equipment)
Ch 19        ←→    Clause 14 (Marking)
```

### Safety Standards Integration
```
ISO 12100 (Risk Assessment)
    ↓
ISO 13849-1 OR IEC 62061 (Safety Functions)
    ↓
IEC 60204-1 (Electrical Implementation)
```

## Business Applications

This structure enables **12 AI-powered tools**:

1. **Standards Intelligence** - RAG-powered standards navigation
2. **Design Framework** - Standards-based design patterns
3. **Troubleshooting Decision Engine** - Diagnostic decision trees
4. **Commissioning Checklists** - Standards verification
5. **Audit Tool** - Compliance scoring
6. **Design Package Generator** - Standards-compliant designs
7. **Retainer Support Engine** - Standards update tracking
8. **Knowledge Platform** - Standards navigation
9. **UL 508A Panel Automation** - Automated UL compliance
10. **Training & Certification Builder** - Standards training modules
11. **IP Library & Licensing** - Standards-based IP
12. **Business Metrics** - Compliance metrics dashboard

## Automation Opportunities

### High Automation Potential
1. **SCCR Calculation** (UL 508A Section SB) - Weakest-link algorithm
2. **Wire Sizing** (NEC Article 310, UL 508A Section 5) - Ampacity calculations
3. **Spacing Validation** (UL 508A Section 4) - Voltage-based clearance checking
4. **Dual-Compliance Checker** - IEC + NFPA simultaneous verification

### Medium Automation Potential
5. **Grounding conductor sizing** - Based on NEC Article 250
6. **Nameplate generation** - UL 508A and NFPA 79 requirements
7. **Regional adaptation** - US ↔ EU design conversion
8. **Component equivalency** - UL ↔ CE component mapping

## Migration from Old Structure

If migrating from `/Users/kyawminthu/Dev/tools/rag/standards_intelligence/`:

**Completed Standards** (already exist in old location):
```bash
# Copy existing complete standards to new structure:
cp -r /Users/kyawminthu/Dev/tools/rag/standards_intelligence/NEC/* \
      control-standards/rag/standards_intelligence/nec/

cp -r /Users/kyawminthu/Dev/tools/rag/standards_intelligence/NFPA/* \
      control-standards/rag/standards_intelligence/nfpa79/

cp -r /Users/kyawminthu/Dev/tools/rag/standards_intelligence/UL/* \
      control-standards/rag/standards_intelligence/ul_508a/

cp -r /Users/kyawminthu/Dev/tools/rag/standards_intelligence/ISO_IEC/iec_60204_1/* \
      control-standards/rag/standards_intelligence/iec_60204_1/
```

## Next Steps

### Phase 1: Immediate (Complete Existing Standards)
1. **Migrate** 4 complete standards modules from old location
2. **Verify** all files have correct metadata
3. **Update** index files for new structure
4. **Test** RAG routing with new paths

### Phase 2: Safety Standards (Weeks 1-4)
1. **ISO 13849-1** - Safety control systems (Performance Levels)
2. **ISO 12100** - Risk assessment foundation
3. **IEC 62061** - Functional safety (SIL)
4. **Map** to existing IEC 60204-1 and NFPA 79

### Phase 3: Design Framework (Weeks 5-8)
1. **Control system design** - PLC/PAC architecture patterns
2. **Safety architecture** - Safety-rated control design
3. **I/O architecture** - I/O system design patterns
4. **Power distribution** - Panel power design templates

### Phase 4: Troubleshooting & Tools (Weeks 9-12)
1. **Build decision trees** for 5 troubleshooting categories
2. **Create commissioning checklists** for 4 phases
3. **Develop automation tools** (SCCR, wire sizing, spacing)
4. **Build training modules** for 4 areas

## Directory Statistics

| Metric | Count |
|--------|-------|
| **Total Directories** | 49 |
| **RAG Directories** | 35 |
| **Standards Modules (Complete)** | 4 |
| **Standards Modules (Planned)** | 5 |
| **Design Framework Modules** | 6 |
| **Troubleshooting Categories** | 5 |
| **Commissioning Phases** | 4 |
| **Training Modules** | 4 |
| **Governance Files** | 5 README files |
| **Index Files** | 2 YAML files |

## File Locations Reference

**Main Documentation**:
- Repository overview: `/control-standards/README.md`
- Structure summary: `/control-standards/STRUCTURE_SUMMARY.md` (this file)

**Governance Files**:
- Drafts policy: `/control-standards/drafts/README.md`
- Design drafts guide: `/control-standards/design_drafts/README.md`
- Exports guide: `/control-standards/exports/README.md`

**Index Files**:
- Standards master index: `/control-standards/rag/standards_intelligence/_index.yaml`
- Troubleshooting index: `/control-standards/rag/troubleshooting_engine/decision_trees.yaml`

**Standards Modules** (from old repository):
- NEC: `/Users/kyawminthu/Dev/tools/rag/standards_intelligence/NEC/`
- NFPA 79: `/Users/kyawminthu/Dev/tools/rag/standards_intelligence/NFPA/`
- UL 508A: `/Users/kyawminthu/Dev/tools/rag/standards_intelligence/UL/`
- IEC 60204-1: `/Users/kyawminthu/Dev/tools/rag/standards_intelligence/ISO_IEC/iec_60204_1/`

---

## ✅ Structure Complete

**Status**: All directories created, governance files in place, ready for content migration and development.

**Next Action**: Migrate 4 complete standards modules from old repository or begin Phase 2 (safety standards development).

**Last Updated**: 2026-01-15

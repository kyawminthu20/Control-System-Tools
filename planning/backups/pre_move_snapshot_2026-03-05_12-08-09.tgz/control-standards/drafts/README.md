# DRAFTS - ABSOLUTE NO-AI ZONE

**AI_READ_ACCESS: FORBIDDEN**
**CONTENT_CLASS: RESTRICTED**

## ⚠️ CRITICAL WARNING

This directory contains **copyrighted material** and **unverified content** that must NEVER be indexed or read by AI systems.

## Purpose

This is a secure workspace for:
1. **Copied standard text** - Verbatim text from purchased standards (NEVER for AI)
2. **Raw notes** - Unverified notes and research
3. **Vendor documentation** - Proprietary vendor materials

## Subdirectories

### `/copied_standard_text/` - NEVER INDEXED
Contains verbatim text from purchased standards:
- NFPA 79, NEC, UL 508A (US standards)
- IEC 60204-1, ISO 13849-1, etc. (International standards)

**PURPOSE**: Human reference only when creating paraphrased content for `/rag/`

**RULES**:
- ❌ NEVER read by AI
- ❌ NEVER indexed for RAG
- ❌ NEVER copy-pasted to `/rag/`
- ✅ Human reference for understanding
- ✅ Source for paraphrasing into RAG-safe content

### `/raw_notes/` - Unverified Content
Personal notes, research, and unverified information:
- Meeting notes
- Research findings
- Draft ideas
- Unverified claims

**PURPOSE**: Working space before verification and promotion to `/rag/`

### `/vendor_docs/` - Proprietary Material
Vendor-provided documentation:
- Product manuals
- Technical specifications
- Proprietary design guides
- Marketing materials

**PURPOSE**: Reference for design work, not for AI indexing

## Workflow

### From `/drafts/` to `/rag/`

1. **Read** copyrighted standard from `/copied_standard_text/` (human only)
2. **Understand** the intent and requirements
3. **Paraphrase** into engineering guidance (NO verbatim text)
4. **Create** new document in `/design_drafts/` or directly in `/rag/`
5. **Add** metadata headers (CONTENT_CLASS: RAG_APPROVED)
6. **Verify** copyright compliance (zero verbatim standard text)
7. **Promote** to `/rag/` for AI indexing

### Example Paraphrasing

**❌ WRONG (verbatim from standard)**:
> "The disconnecting means shall be located within sight of the machine."

**✅ CORRECT (paraphrased intent)**:
> Engineers should ensure disconnect switches are visually accessible from the machine control point. This supports safety by allowing operators to verify isolation before maintenance.

## Copyright Compliance

### What Goes in `/drafts/copied_standard_text/`
- ✅ PDF copies of purchased standards
- ✅ Photocopies of standard pages
- ✅ Quoted text blocks for human reference
- ✅ Standard text used for paraphrasing

### What NEVER Goes in `/rag/`
- ❌ Any verbatim standard text
- ❌ Direct quotes from standards
- ❌ Copy-pasted requirement text
- ❌ Scanned standard pages

### What CAN Go in `/rag/` (after paraphrasing)
- ✅ Engineering interpretation of requirements
- ✅ Practical guidance based on standard intent
- ✅ Design checklists derived from requirements
- ✅ Paraphrased explanations
- ✅ Standard identifiers (chapter/article/section numbers)
- ✅ Standard titles and organizational structure

## Legal Protection

By keeping copyrighted material strictly in `/drafts/` and marking it AI_READ_ACCESS: FORBIDDEN, we:

1. **Protect copyright holders** - No distribution of copyrighted text
2. **Maintain compliance** - Clear separation of copyrighted vs derivative work
3. **Enable AI tools** - RAG-safe paraphrased content in `/rag/`
4. **Support audits** - Clear governance and traceability

## Access Control

### Who Can Access `/drafts/`
- ✅ Human engineers (for reference)
- ✅ Standards committee members
- ✅ Quality/compliance personnel

### Who CANNOT Access `/drafts/`
- ❌ AI systems (RAG, LLM, ML tools)
- ❌ Automated indexing tools
- ❌ Web scrapers
- ❌ Unauthorized personnel

## Audit Trail

When using content from `/drafts/`:

1. Document which standard was referenced
2. Note date and edition
3. Verify paraphrasing is complete (no verbatim text)
4. Add changelog entry to target file
5. Mark source file in `/drafts/` as "referenced for [filename]"

## Directory Protection

### Technical Safeguards
- `.gitignore` excludes `/drafts/` from version control
- AI tools configured with AI_READ_ACCESS: FORBIDDEN flag
- File permissions restrict automated access
- Audit logging tracks all access

### Process Safeguards
- Mandatory copyright compliance training
- Peer review before `/rag/` promotion
- Regular audits of `/rag/` content
- Clear governance documentation

## Standards Purchase

Always purchase official standards from:
- **NFPA**: https://www.nfpa.org/codes-and-standards
- **IEC**: https://webstore.iec.ch/
- **ISO**: https://www.iso.org/store.html
- **UL**: https://www.shopulstandards.com/

Store purchased PDFs in `/drafts/copied_standard_text/` for human reference.

---

**REMEMBER**: The goal is to create valuable, AI-accessible engineering guidance in `/rag/` while strictly protecting copyrighted material in `/drafts/`. Always paraphrase. Never copy-paste.

**Last Updated**: 2026-01-15

# Quick Start Guide - Control Standards Repository

**Last Updated:** 2026-01-15

## 🚀 Getting Started in 5 Minutes

### 1. Understand the Structure (30 seconds)

```
control-standards/
├── rag/                    # ✅ AI can read - Authoritative knowledge
├── design_drafts/          # ⚠️ AI caution - Your working space
├── drafts/                 # ❌ AI forbidden - Copyrighted standards
└── exports/                # 📄 Output - Client deliverables
```

### 2. First Time Setup (2 minutes)

**Option A: Start Fresh**
```bash
cd /Users/kyawminthu/Dev/tools/control-standards
# Structure is ready - start adding content
```

**Option B: Migrate Existing Standards**
```bash
# Copy your existing complete standards:
cp -r /Users/kyawminthu/Dev/tools/rag/standards_intelligence/NEC/* \
      rag/standards_intelligence/nec/

cp -r /Users/kyawminthu/Dev/tools/rag/standards_intelligence/NFPA/* \
      rag/standards_intelligence/nfpa79/

cp -r /Users/kyawminthu/Dev/tools/rag/standards_intelligence/UL/* \
      rag/standards_intelligence/ul_508a/

cp -r /Users/kyawminthu/Dev/tools/rag/standards_intelligence/ISO_IEC/iec_60204_1/* \
      rag/standards_intelligence/iec_60204_1/
```

### 3. Core Workflows (2.5 minutes)

#### Workflow A: Looking Up a Standard Requirement
```bash
# 1. Navigate to standard
cd rag/standards_intelligence/nfpa79/

# 2. Check the overview
cat NFPA_OVERVIEW.md

# 3. Find specific chapter (e.g., Chapter 8 - Grounding)
cat NFPA79_2024__Ch08__grounding_and_bonding.md

# 4. For cross-references between standards:
cat ../iec_60204_1/IEC60204_1_2018__Clause08__equipotential_bonding.md
```

#### Workflow B: Creating a Design
```bash
# 1. Start in design_drafts
cd design_drafts/scratch_notes/

# 2. Create your design file
echo "# Robot Cell Power Distribution - 2026-01-15" > robot_power_design.md

# 3. Reference standards from /rag/standards_intelligence/
# 4. When complete, promote to /rag/design_framework/
```

#### Workflow C: Troubleshooting
```bash
# 1. Navigate to troubleshooting category
cd rag/troubleshooting_engine/digital_io/

# 2. Follow decision tree for symptom
# 3. Link to standards for verification
```

## 📚 What's Already Available

### ✅ Complete Standards (4 modules, 71 files, 56 elements)

| Standard | Location | Elements | Status |
|----------|----------|----------|--------|
| **NEC 2023** | `rag/standards_intelligence/nec/` | 10 articles | ✅ Ready |
| **NFPA 79 2024** | `rag/standards_intelligence/nfpa79/` | 20 chapters | ✅ Ready |
| **UL 508A 2022** | `rag/standards_intelligence/ul_508a/` | 11 sections | ✅ Ready |
| **IEC 60204-1 2018** | `rag/standards_intelligence/iec_60204_1/` | 15 clauses | ✅ Ready |

### 🔄 Planned Standards

- ISO 13849-1 (Safety - Performance Levels)
- ISO 12100 (Risk Assessment)
- IEC 62061 (Functional Safety - SIL)
- IEC 61508 (Functional Safety Foundation)
- IEC 61511 (Process Industry Safety)

## 🎯 Common Tasks

### Task 1: "I need to design a UL-listed control panel"

**Standards Required**: NEC Article 409, UL 508A, NFPA 79 Ch 11

```bash
cd rag/standards_intelligence/

# Read Article 409 for NEC requirements
cat nec/NEC_2023__Art409__industrial_control_panels.md

# Read UL 508A for panel design
cat ul_508a/UL508A_2022__OVERVIEW.md

# Check NFPA 79 for machinery integration
cat nfpa79/NFPA79_2024__Ch11__control_equipment.md

# Start your design
cd ../../design_drafts/scratch_notes/
nano my_panel_design.md
```

**Key Sections**:
- UL 508A Section SB (SCCR calculation) - CRITICAL
- UL 508A Section 4 (Spacing)
- UL 508A Section 5 (Wire sizing)
- NEC Article 250 (Grounding)

### Task 2: "I need CE marking for international machinery"

**Standards Required**: IEC 60204-1, ISO 13849-1, ISO 12100

```bash
cd rag/standards_intelligence/

# Read IEC 60204-1 overview
cat iec_60204_1/IEC60204_OVERVIEW.md

# Critical clauses for CE marking:
cat iec_60204_1/IEC60204_1_2018__Clause08__equipotential_bonding.md
cat iec_60204_1/IEC60204_1_2018__Clause09__control_circuits_and_functions.md
cat iec_60204_1/IEC60204_1_2018__Clause14__marking_and_documentation.md
```

### Task 3: "I need both US and EU compliance"

**Standards Required**: NFPA 79 + IEC 60204-1 (dual compliance)

```bash
cd rag/standards_intelligence/

# Check equivalents side-by-side:
# Grounding/Bonding:
cat nfpa79/NFPA79_2024__Ch08__grounding_and_bonding.md
cat iec_60204_1/IEC60204_1_2018__Clause08__equipotential_bonding.md

# Control Circuits:
cat nfpa79/NFPA79_2024__Ch09__control_circuits.md
cat iec_60204_1/IEC60204_1_2018__Clause09__control_circuits_and_functions.md

# Use MOST RESTRICTIVE from each standard
```

### Task 4: "Digital input not reading - troubleshoot"

```bash
cd rag/troubleshooting_engine/digital_io/

# Follow decision tree (to be created):
# 1. Check power supply voltage
# 2. Verify wiring continuity
# 3. Check input module status
# 4. Verify PLC configuration
# 5. Check program logic

# Reference standards for verification:
# NFPA 79 Ch 11 - Control Equipment
```

### Task 5: "Calculate SCCR for panel"

**Standard**: UL 508A Section SB

```bash
cd rag/standards_intelligence/ul_508a/

# Read SCCR section
cat UL508A_2022__sccr_short_circuit_current_rating.md

# Automated tool (to be developed):
# sccr_calculator --bom panel_bom.csv --output exports/reports/sccr_report.pdf
```

## 🔑 Key Files to Read First

1. **Repository Overview**: `README.md`
2. **Structure Summary**: `STRUCTURE_SUMMARY.md`
3. **This Guide**: `QUICK_START.md`

**Then by Use Case**:

**For US Control Panels**:
- `rag/standards_intelligence/ul_508a/UL508A_OVERVIEW.md`
- `rag/standards_intelligence/nec/NEC_OVERVIEW.md`

**For Industrial Machinery (US)**:
- `rag/standards_intelligence/nfpa79/NFPA_OVERVIEW.md`

**For International/EU Machinery**:
- `rag/standards_intelligence/iec_60204_1/IEC60204_OVERVIEW.md`

## 🚫 What NOT to Do

### ❌ DON'T: Copy standard text to `/rag/`
```bash
# WRONG - This violates copyright
cp /path/to/NFPA79.pdf drafts/copied_standard_text/  # This is OK
cat drafts/copied_standard_text/NFPA79.pdf > rag/nfpa79/chapter.md  # NO!
```

### ✅ DO: Paraphrase and create guidance
```bash
# CORRECT - Read copyrighted text (human only), paraphrase into guidance
# 1. Read standard (human only): drafts/copied_standard_text/NFPA79.pdf
# 2. Understand intent and requirements
# 3. Write paraphrased guidance: rag/nfpa79/NFPA79_2024__Ch08__grounding_and_bonding.md
# 4. NO verbatim text - only interpretation and guidance
```

### ❌ DON'T: Let AI read `/drafts/`
```bash
# AI systems should NEVER read from /drafts/
# This directory contains copyrighted material
```

### ✅ DO: Use `/design_drafts/` for working space
```bash
# Work here, AI can help with caution
cd design_drafts/scratch_notes/
nano my_design_notes.md
```

## 📊 Priority Content to Develop First

### Phase 1: Critical Standards Content (Weeks 1-2)

**US Panel Design** (UL listing):
1. UL 508A Section SB (SCCR calculation)
2. UL 508A Section 4 (Spacing)
3. UL 508A Section 5 (Wire sizing)
4. NEC Article 250 (Grounding)
5. NEC Article 409 (Industrial Control Panels)

**International Machinery** (CE marking):
1. IEC 60204-1 Clause 8 (Equipotential Bonding)
2. IEC 60204-1 Clause 9 (Control Circuits/E-stop)
3. IEC 60204-1 Clause 14 (Marking)

### Phase 2: Safety Standards (Weeks 3-4)
1. ISO 13849-1 (Performance Levels)
2. ISO 12100 (Risk Assessment)
3. IEC 62061 (SIL ratings)

### Phase 3: Design Framework (Weeks 5-8)
1. Control system design patterns
2. Safety architecture templates
3. I/O architecture patterns
4. Power distribution templates

### Phase 4: Tools & Automation (Weeks 9-12)
1. SCCR calculator
2. Wire sizing automation
3. Dual-compliance checker
4. Troubleshooting decision trees

## 🛠️ Automation Tools (Planned)

### Ready for Implementation
1. **SCCR Calculator** - Input: BOM → Output: SCCR rating
2. **Wire Sizing Tool** - Input: Load → Output: Wire size per NEC/UL 508A
3. **Spacing Validator** - Input: Voltage → Output: Required clearances
4. **Dual-Compliance Checker** - Input: Design → Output: US+EU compliance report

### Requires More Development
5. **CE Documentation Generator** - Generate CE marking documentation
6. **Regional Adapter** - Convert US design to EU and vice versa
7. **Commissioning Package Generator** - Auto-generate commissioning checklists

## 💡 Tips and Best Practices

### For AI Systems
- **READ** from `/rag/` only
- **NEVER READ** from `/drafts/`
- **CAUTION** with `/design_drafts/` (work in progress)
- **READ-ONLY** from `/exports/` (client deliverables)

### For Human Engineers
- **Start designs** in `/design_drafts/`
- **Reference standards** from `/rag/standards_intelligence/`
- **Keep copyrighted text** in `/drafts/copied_standard_text/`
- **Promote verified content** to `/rag/` when ready
- **Export deliverables** to `/exports/`

### For Content Development
1. Always add metadata headers
2. Use TODO placeholders for incomplete sections
3. Add embedded changelog to every file
4. Reference related standards
5. Use priority markers (CRITICAL, HIGH, Standard)

## 📞 Getting Help

### Documentation Files
- Main README: `README.md`
- Structure details: `STRUCTURE_SUMMARY.md`
- Drafts policy: `drafts/README.md`
- Design drafts guide: `design_drafts/README.md`
- Exports guide: `exports/README.md`

### Master Index Files
- Standards index: `rag/standards_intelligence/_index.yaml`
- Troubleshooting index: `rag/troubleshooting_engine/decision_trees.yaml`

### Standard Overviews
- NFPA 79: `rag/standards_intelligence/nfpa79/NFPA_OVERVIEW.md`
- NEC: `rag/standards_intelligence/nec/NEC_OVERVIEW.md`
- UL 508A: `rag/standards_intelligence/ul_508a/UL508A_OVERVIEW.md`
- IEC 60204-1: `rag/standards_intelligence/iec_60204_1/IEC60204_OVERVIEW.md`

## ✅ Checklist: Am I Using This Correctly?

**Before starting work**:
- [ ] I understand the four-tier structure
- [ ] I know which directory to use for my task
- [ ] I've read the relevant README files
- [ ] I know the copyright compliance rules

**When adding content to `/rag/`**:
- [ ] Content is paraphrased (NO verbatim standard text)
- [ ] Metadata headers are complete
- [ ] Changelog entry added
- [ ] Cross-references documented
- [ ] File follows naming convention

**When exporting to clients**:
- [ ] Content is verified and accurate
- [ ] No copyrighted verbatim text included
- [ ] Professional formatting applied
- [ ] Version number clear
- [ ] Saved to correct `/exports/` subdirectory

---

## 🎉 You're Ready!

Start with:
1. **Browse existing standards** in `rag/standards_intelligence/`
2. **Try a design** in `design_drafts/scratch_notes/`
3. **Reference standards** for compliance
4. **Export deliverable** when ready

**Next Steps**: See [README.md](README.md) for full documentation or [STRUCTURE_SUMMARY.md](STRUCTURE_SUMMARY.md) for detailed structure overview.

**Last Updated**: 2026-01-15

# Drafts
**AI_READ_ACCESS: FORBIDDEN**

This folder contains brainstorms, partial work, messy notes, and unverified content.

## Purpose
Working space for ideas, experiments, and content development BEFORE it's ready for the authoritative RAG folder.

## Important Rules
- AI tools should NEVER read from this folder
- Content here is NOT verified or approved
- This is a "thinking out loud" space for humans
- Content must be reviewed and promoted to /rag/ before AI can use it

## Subfolders
- **00_inbox_notes.md**: Capture new ideas quickly
- **standards_notes/**: Raw notes from standards reading (unverified)
- **design_working/**: Evolving design ideas (not approved)
- **troubleshooting_logs/**: Field incident narratives
- **commissioning_notes/**: Site visit notes
- **experiments/**: Sandbox for trying new approaches

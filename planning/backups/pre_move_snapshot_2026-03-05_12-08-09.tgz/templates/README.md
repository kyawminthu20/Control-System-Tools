# Templates
**AI_READ_ACCESS: ALLOWED (for template reference)**

Starting templates for creating new content. Copy templates into /drafts/, fill in, then promote to /rag/ when approved.

## Contents

### md_headers/
Standard headers for different content types:
- **rag_approved_header.md**: Header for authoritative RAG content
- **draft_only_header.md**: Header for draft content
- **archived_header.md**: Header for archived content

### design_guides/
- **design_guide_template.md**: Template for creating new design guides

### reports/
- **report_template.md**: Template for generated reports

### checklists/
- **checklist_template.md**: Template for creating checklists

## Usage
1. Copy appropriate template to /drafts/
2. Rename file to match your content
3. Fill in template sections
4. Follow promotion checklist when ready to move to /rag/

# Change Management
**AI_READ_ACCESS: ALLOWED (for process understanding)**

This folder defines the human processes and policies for promoting content from drafts → RAG, managing design changes, and tracking decisions.

## Purpose
Enforce quality gates and maintain integrity of the authoritative RAG knowledge base.

## Contents
- **promotion_checklist_drafts_to_rag.md**: Steps to verify before promoting content
- **design_change_policy.md**: When and how to update design frameworks
- **decision_log.md**: High-level architectural and process decisions
- **release_notes.md**: Project-level release snapshots

## Key Principles
1. **Authoritative RAG only**: AI reads only from /rag/, never /drafts/
2. **Promotion requires review**: Use checklist before moving content
3. **Changelog discipline**: Every RAG file must have embedded changelog
4. **Decision transparency**: Log significant decisions in decision_log.md

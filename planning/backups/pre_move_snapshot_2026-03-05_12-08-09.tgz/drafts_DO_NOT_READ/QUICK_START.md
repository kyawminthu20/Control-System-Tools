# Quick Start Guide

## Getting Started with the Control System Engineering Project Template

---

## Step 1: Copy Template to Your Project Location

Copy the `control_system_project_template` folder to your working directory and rename it to your project name.

Example:
```
cp -r control_system_project_template ~/projects/conveyor_system_acme_2024
```

---

## Step 2: Update Project README

Edit `README.md` in the root directory:
- Set project name and system type
- Define safety level target
- Check applicable standards
- Document known risks
- Set project purpose

---

## Step 3: Configure Standards

Edit `rag/_standards_map.md`:
- Mark applicable standards
- Document where compliance is captured
- Add project-specific standards if needed

---

## Step 4: Start Design Work

### Option A: Create from Template
1. Copy template from `templates/design_guides/design_guide_template.md`
2. Paste into `drafts/design_working/`
3. Rename appropriately
4. Fill in content

### Option B: Use Existing Examples
1. Review examples in `rag/design_framework/design_guides/`
2. Copy relevant sections
3. Modify for your project

---

## Step 5: Capture Knowledge

### Standards Research
Work in: `drafts/standards_notes/`
- Document clause interpretations
- Research design constraints
- Identify red flags

When verified, extract to: `rag/standards_intelligence/`

### Design Development
Work in: `drafts/design_working/`
- Iterate on designs
- Document open questions
- Evaluate alternatives

When approved, promote to: `rag/design_framework/design_guides/`

### Field Observations
Work in: `drafts/commissioning_notes/` or `drafts/troubleshooting_logs/`
- Document incidents
- Capture site notes
- Record discoveries

When validated, extract to: `rag/troubleshooting_decision_engine/` or update design guides

---

## Step 6: Promote Approved Content

When content is ready:
1. Review `change_management/promotion_checklist_drafts_to_rag.md`
2. Verify quality and completeness
3. Copy (don't move) to appropriate `rag/` location
4. Add YAML header from `templates/md_headers/rag_approved_header.md`
5. Update embedded changelog
6. Log significant decisions in `change_management/decision_log.md`

---

## Step 7: Manage Changes

### Document Design Changes
1. Update affected design guide(s)
2. Add entry to embedded changelog
3. Deprecate old decisions with strikethrough
4. Never delete historical decisions

### Log Major Decisions
1. Add entry to `change_management/decision_log.md`
2. Include alternatives considered
3. Document rationale
4. Note impact

---

## Step 8: Build Tool Content

As project matures, populate tool-specific folders:

### Standards Intelligence (Tool 1)
- `rag/standards_intelligence/clause_index/` - Add clause references
- `rag/standards_intelligence/rules_engine/` - Extract design constraints

### Troubleshooting (Tool 3)
- `rag/troubleshooting_decision_engine/decision_trees/` - Build decision trees
- Extract from field incidents and validated solutions

### Commissioning (Tool 4)
- `rag/commissioning_checklists/` - Create project-specific checklists
- Customize from templates

### Design Packages (Tool 6)
- `rag/design_package_generator/kits/` - Assemble reusable kits
- Package for sale or reuse

---

## Step 9: Generate Deliverables

### Reports
Generate from markdown sources to PDF:
- Audit reports
- Design packages
- Commissioning documentation

Store in: `exports/pdf/`

### Data Exports
Export structured data:
- I/O lists to CSV
- BOMs to CSV
- Metrics to CSV

Store in: `exports/csv/`

---

## Best Practices

### Use Embedded Changelogs
Every design guide should have:
```markdown
## Design Change Log

| Date | Change | Reason | Impact | Designer |
|------|--------|--------|--------|----------|
```

### Maintain AI Boundaries
- **rag/**: Approved, authoritative content only
- **drafts/**: Work in progress, unverified
- **archive/**: Historical, superseded content

### Follow Naming Conventions
- Review `NAMING_CONVENTIONS.md`
- Use consistent formats
- Include dates: YYYY-MM-DD
- Use descriptive names

### Document Decisions
Don't just document what, document why:
- Why this component?
- Why this approach?
- What alternatives were rejected?
- What constraints drove this?

### Preserve History
- Don't delete deprecated decisions
- Strike through with ~~text~~
- Explain why something changed
- Keep drafts after promotion

---

## Example Workflow

### New Machine Project

1. Copy template → `pump_skid_chemical_2024/`
2. Update README: System type = "Process Skid", Safety = "PLd"
3. Mark standards: NEC, NFPA 79, UL 508A, ISO 13849
4. Create draft: `drafts/design_working/pump_control_design.md`
5. Research VFD sizing, document in draft
6. Create I/O list, document in draft
7. Develop safety architecture, document in draft
8. Review and approve
9. Promote to: `rag/design_framework/design_guides/01_pump_skid_design_guide.md`
10. Add changelog entry
11. Log major decisions in decision log
12. Build commissioning checklists
13. Execute project
14. Capture field notes in `drafts/commissioning_notes/`
15. Update design guides with field-validated changes
16. Generate audit report using `rag/audit_tool/`
17. Export final deliverables

---

## Tools Usage

### Phase 1 (Current Project)
- Standards Intelligence: Research and apply standards
- Design Framework: Create design guides
- Troubleshooting Engine: Build from field experience
- Commissioning Checklists: Execute and refine

### Phase 2 (Productization)
- Audit Tool: Offer compliance audits
- Design Package Generator: Package reusable kits
- Retainer Support: Provide ongoing support

### Phase 3 (Scaling)
- Knowledge Platform: Aggregate and cross-reference
- UL 508A Automation: Streamline panel design
- Training Builder: Create training offerings

### Phase 4 (Exit Preparation)
- IP Library: Catalog and license IP
- Business Metrics: Track profitability

---

## Getting Help

### Documentation
- `PROJECT_STRUCTURE.md` - Complete structure overview
- `NAMING_CONVENTIONS.md` - Naming standards
- `change_management/design_change_policy.md` - Change process
- Individual tool READMEs in `rag/*/README.md`

### Templates
- `templates/design_guides/design_guide_template.md`
- `templates/md_headers/` - YAML headers
- Use as starting points

---

## Success Metrics

You'll know the system is working when:
- Design intent is captured, not just final answers
- Changes are traceable
- Drafts flow smoothly to approved content
- Field lessons update design guides
- Knowledge is reusable across projects
- Audits and deliverables are straightforward
- IP is identifiable and extractable

---

## Next Steps

1. Copy template
2. Customize for first project
3. Use it actively
4. Refine based on what works
5. Build tool content over time
6. Scale to additional projects
7. Productize when ready

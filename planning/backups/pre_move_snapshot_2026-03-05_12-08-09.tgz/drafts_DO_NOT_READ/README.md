# Control System Engineering Project

## Project Information

**Project Name:** [Project Name]
**System Type:** [Control Panel / Machine / Conveyor / Process Skid / Robotic Cell]
**Safety Level Target:** [None / SIL1 / SIL2 / SIL3 / PLd / PLe]
**Design Maturity:** [Concept / Design / Build / Commission / Operations]

## Standards in Scope

- [ ] NEC
- [ ] NFPA 79
- [ ] UL 508A
- [ ] ISO 13849
- [ ] IEC 62061
- [ ] IEC 61508

## Known Risks

1. [Risk description]
2. [Risk description]

## Tool Coverage Status

| Tool | Status | Notes |
|------|--------|-------|
| Standards Intelligence | [ ] | |
| Design Framework | [ ] | |
| Troubleshooting Engine | [ ] | |
| Commissioning Checklists | [ ] | |
| Audit Tool | [ ] | |
| Design Package Generator | [ ] | |
| Retainer Support | [ ] | |
| Knowledge Platform | [ ] | |
| UL 508A Automation | [ ] | |
| Training/Cert Builder | [ ] | |
| IP Library | [ ] | |
| Business Metrics | [ ] | |

## Project Purpose

[Describe the purpose and scope of this control system project]

## Quick Navigation

- Standards Intelligence: `rag/standards_intelligence/`
- Design Guides: `rag/design_framework/design_guides/`
- Troubleshooting: `rag/troubleshooting_decision_engine/`
- Commissioning: `rag/commissioning_checklists/`
- Working Drafts: `drafts/`
- Change Log: `change_management/decision_log.md`

# Control System Engineering Project Structure

## Overview
Standardized offline-first project template for industrial control systems engineering.

---

## Folder Tree

```
control_system_project_template/
├── README.md                           # Project overview, status, navigation
├── NAMING_CONVENTIONS.md               # Naming standards for all files/folders
│
├── rag/                                # AI_READ_ACCESS: ALLOWED
│   ├── _index.yaml                     # RAG routing rules
│   ├── _glossary.md                    # Approved terminology
│   ├── _standards_map.md               # Standards applicability map
│   │
│   ├── standards_intelligence/         # Tool 1
│   │   ├── README.md
│   │   ├── clause_index/
│   │   │   ├── nec_clause_index.yaml
│   │   │   ├── nfpa79_clause_index.yaml
│   │   │   ├── ul508a_clause_index.yaml
│   │   │   └── iso_iec_clause_index.yaml
│   │   ├── rules_engine/
│   │   │   ├── rules.yaml
│   │   │   └── red_flags.yaml
│   │   └── outputs/
│   │       └── standards_guidance_report.md
│   │
│   ├── design_framework/               # Tool 2
│   │   ├── README.md
│   │   ├── design_guides/
│   │   │   ├── 01_panel_design_guide.md
│   │   │   ├── 02_power_distribution_guide.md
│   │   │   ├── 03_io_architecture_guide.md
│   │   │   ├── 04_safety_architecture_guide.md
│   │   │   ├── 05_network_architecture_guide.md
│   │   │   ├── 06_motion_architecture_guide.md
│   │   │   └── 07_plc_software_structure_guide.md
│   │   ├── patterns/
│   │   │   ├── io_templates.yaml
│   │   │   ├── power_patterns.yaml
│   │   │   ├── safety_patterns.yaml
│   │   │   ├── network_topologies.yaml
│   │   │   └── plc_structure_patterns.yaml
│   │   ├── constraints/
│   │   │   ├── wiring_separation_rules.yaml
│   │   │   └── grounding_bonding_rules.yaml
│   │   └── outputs/
│   │       └── design_pack.md
│   │
│   ├── troubleshooting_decision_engine/  # Tool 3
│   │   ├── README.md
│   │   ├── decision_trees/
│   │   │   ├── digital_io_tree.yaml
│   │   │   ├── analog_io_tree.yaml
│   │   │   ├── ethernet_ip_tree.yaml
│   │   │   ├── ethercat_tree.yaml
│   │   │   ├── profinet_tree.yaml
│   │   │   ├── servo_faults_tree.yaml
│   │   │   └── pid_instability_tree.yaml
│   │   ├── playbooks/
│   │   │   ├── digital_io_playbook.md
│   │   │   ├── analog_io_playbook.md
│   │   │   ├── networks_playbook.md
│   │   │   └── motion_playbook.md
│   │   └── outputs/
│   │       └── troubleshooting_pack.md
│   │
│   ├── commissioning_checklists/       # Tool 4
│   │   ├── README.md
│   │   ├── checklists/
│   │   │   ├── pre_power_checklist.md
│   │   │   ├── dry_run_checklist.md
│   │   │   ├── live_run_checklist.md
│   │   │   └── handover_checklist.md
│   │   └── outputs/
│   │       └── commissioning_pack.md
│   │
│   ├── audit_tool/                     # Tool 5
│   │   ├── README.md
│   │   ├── scoring_model.yaml
│   │   ├── risk_ranking.yaml
│   │   ├── technical_debt_model.yaml
│   │   ├── report_templates/
│   │   │   └── audit_report_template.md
│   │   └── outputs/
│   │       └── audit_report.md
│   │
│   ├── design_package_generator/       # Tool 6
│   │   ├── README.md
│   │   └── kits/
│   │       ├── conveyor_control_kit/
│   │       │   ├── kit_overview.md
│   │       │   ├── architecture.md
│   │       │   ├── safety.md
│   │       │   ├── plc_structure.md
│   │       │   ├── network_design.md
│   │       │   └── bill_of_materials.md
│   │       ├── pump_skid_control_kit/
│   │       │   └── [same structure]
│   │       └── robotic_cell_control_kit/
│   │           └── [same structure]
│   │
│   ├── retainer_support_engine/        # Tool 7
│   │   ├── README.md
│   │   ├── monthly_health_check.md
│   │   ├── incident_response_framework.md
│   │   ├── upgrade_planning_logic.yaml
│   │   └── outputs/
│   │       └── monthly_review_report.md
│   │
│   ├── knowledge_platform/             # Tool 8
│   │   ├── README.md
│   │   ├── navigation.md
│   │   └── training_modules_index.md
│   │
│   ├── ul508a_panel_automation/        # Tool 9
│   │   ├── README.md
│   │   ├── bom_generator_rules.yaml
│   │   ├── spacing_clearance_rules.yaml
│   │   ├── ul_documentation_templates/
│   │   │   └── ul_panel_doc_template.md
│   │   ├── revision_tracking.yaml
│   │   └── outputs/
│   │       └── ul508a_doc_pack.md
│   │
│   ├── training_cert_builder/          # Tool 10
│   │   ├── README.md
│   │   ├── modules/
│   │   │   ├── plc_architecture_best_practices.md
│   │   │   ├── safety_design.md
│   │   │   ├── commissioning_readiness.md
│   │   │   └── troubleshooting_mastery.md
│   │   └── assessments/
│   │       ├── quizzes.yaml
│   │       └── practical_labs.md
│   │
│   ├── ip_library_licensing/           # Tool 11
│   │   ├── README.md
│   │   ├── ip_catalog.yaml
│   │   ├── licensing_terms.md
│   │   └── export_packages/
│   │       ├── design_framework_bundle.md
│   │       ├── decision_tree_bundle.md
│   │       └── training_bundle.md
│   │
│   └── business_metrics_profit_engine/ # Tool 12
│       ├── README.md
│       ├── metrics_schema.yaml
│       ├── dashboards_offline.md
│       └── exports/
│           └── metrics_snapshot.csv
│
├── drafts/                             # AI_READ_ACCESS: FORBIDDEN
│   ├── README.md
│   ├── 00_inbox_notes.md
│   ├── standards_notes/
│   │   ├── nec_notes.md
│   │   ├── nfpa79_notes.md
│   │   ├── ul508a_notes.md
│   │   └── iso_iec_notes.md
│   ├── design_working/
│   │   ├── panel_design_working.md
│   │   ├── network_design_working.md
│   │   ├── plc_structure_working.md
│   │   └── open_questions.md
│   ├── troubleshooting_logs/
│   │   └── incident_YYYY-MM-DD.md
│   ├── commissioning_notes/
│   │   └── site_notes_YYYY-MM-DD.md
│   └── experiments/
│       ├── pid_tuning_sandbox.md
│       ├── servo_tuning_sandbox.md
│       └── oee_sandbox.md
│
├── archive/                            # AI_READ_ACCESS: MANUAL_ONLY
│   ├── README.md
│   ├── superseded_designs/
│   │   └── design_pack_v1_deprecated.md
│   ├── old_decision_trees/
│   │   └── ethernet_ip_tree_v1.yaml
│   └── past_audits/
│       └── audit_report_YYYY-MM-DD.md
│
├── change_management/
│   ├── README.md
│   ├── promotion_checklist_drafts_to_rag.md
│   ├── design_change_policy.md
│   ├── decision_log.md
│   └── release_notes.md
│
├── templates/
│   ├── README.md
│   ├── md_headers/
│   │   ├── rag_approved_header.md
│   │   ├── draft_only_header.md
│   │   └── archived_header.md
│   ├── design_guides/
│   │   └── design_guide_template.md
│   ├── reports/
│   │   └── report_template.md
│   └── checklists/
│       └── checklist_template.md
│
├── exports/
│   ├── README.md
│   ├── pdf/
│   ├── csv/
│   └── snapshots/
│
├── tools/
│   ├── README.md
│   ├── generate_report.ps1
│   ├── generate_report.sh
│   ├── validate_ai_boundaries.ps1
│   └── validate_ai_boundaries.sh
│
└── data/
    ├── README.md
    ├── plc_exports/
    ├── network_captures/
    └── historian_exports/
```

---

## Key Principles

### 1. Offline-First
- Markdown + YAML only
- No SaaS dependencies
- Local file system
- Portable and archivable

### 2. AI-Aware Boundaries
- **rag/**: Authoritative, AI-readable
- **drafts/**: Work-in-progress, AI-forbidden
- **archive/**: Historical, AI-manual-only

### 3. Embedded Changelogs
All design guides include embedded changelog tables:
```markdown
| Date | Change | Reason | Impact | Designer |
|------|--------|--------|--------|----------|
```

### 4. Tool-Driven Organization
12 tools organized in 4 phases:
- Phase 1: Foundation (Tools 1-4)
- Phase 2: Productized (Tools 5-7)
- Phase 3: Scalable Assets (Tools 8-10)
- Phase 4: Exit-Grade (Tools 11-12)

### 5. Change Management
- Design change policy
- Promotion checklist (drafts → rag)
- Decision log for major choices
- Deprecation without deletion

---

## File Types

### YAML Files
- Clause indexes
- Decision trees
- Rules engines
- Patterns
- Constraints

### Markdown Files
- Design guides
- READMEs
- Checklists
- Reports
- Playbooks
- Documentation

---

## Workflow

1. **Capture** in `drafts/`
2. **Develop** and iterate
3. **Review** against standards
4. **Promote** to `rag/` when approved
5. **Archive** when superseded

---

## Naming Standards

### Folders
- lowercase_with_underscores
- No spaces
- Descriptive, plural for collections

### Files
- lowercase_with_underscores
- Date format: YYYY-MM-DD
- Numbered prefixes for sequences
- Descriptive suffixes (_tree, _guide, _checklist)

### Versions
- Semantic: MAJOR.MINOR.PATCH
- Date-based: YYYY-MM-DD
- Status in YAML header, not filename

---

## Getting Started

1. Copy this template to new project location
2. Update root README.md with project details
3. Populate applicable standards in _standards_map.md
4. Begin design work in drafts/
5. Promote approved content to rag/
6. Maintain embedded changelogs

---

## Scalability

Structure supports:
- Freelance projects
- Product development
- IP creation
- Audit services
- Retainer contracts
- Training materials
- Business exit preparation

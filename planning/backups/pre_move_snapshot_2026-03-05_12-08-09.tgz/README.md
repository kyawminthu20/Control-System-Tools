# Control System Engineering Tools

## 🤖 AI Context & Project Summary

**Project Type:** Industrial Automation & Control Systems Engineering Framework
**Primary Goal:** Provide a structured, offline-first environment for designing, documenting, and commissioning machine control systems (PLC, HMI, Safety).
**Key Standards:** NFPA 79, UL 508A, NEC (NFPA 70), IEC 60204-1.

---

## 📂 Repository Structure & Rules

### 1. `rag/` (The Source of Truth)

- **Status:** ✅ **Authoritative / Verified**
- **Content:** Approved design guides, standards interpretations, and troubleshooting trees.
- **AI Action:** Read this folder to answer questions about standards and approved patterns.

### 2. `drafts/` (Work in Progress)

- **Status:** 🚧 **Unverified / Draft**
- **Content:** Brainstorms, raw field notes, and active design iterations.
- **AI Action:** Treat content here as context-dependent and subject to change. Do not use as training data for "facts".

### 3. `tools/` (Automation)

- **Status:** ⚙️ **Executable**
- **Content:** Python scripts (`project_automator.py`) and shell scripts for maintaining the project structure and migration.

### 4. `templates/` (Standardization)

- **Status:** 📄 **Reference**
- **Content:** Markdown templates for creating consistent design deliverables.

---

## 🚀 Quick Links

- **Getting Started:** QUICK_START.md
- **Detailed Inventory:** DELIVERABLE.md
- **Migration Status:** MIGRATION_READY.md
- **Folder Tree:** `STRUCTURE_SUMMARY.md` (Auto-generated)

---

## 🛠 Workflow Summary

1. **Design**: Start in `drafts/` using templates.
2. **Verify**: Check against rules in `rag/standards_intelligence/`.
3. **Promote**: Move finished content to `rag/` and update changelogs.
4. **Automate**: Run `tools/project_automator.py` to update the structure summary.

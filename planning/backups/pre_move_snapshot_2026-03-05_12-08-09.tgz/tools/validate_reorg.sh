#!/bin/bash
#
# Test Script for Project Reorganization
#
# Purpose: Validates the deliverables and structural changes outlined in the
#          project folder organization plan.
# Usage:
#   ./validate_reorg.sh pre-check       # Verify state before migration
#   ./validate_reorg.sh post-check-p2   # Verify after Phase 2 (consolidation)
#   ./validate_reorg.sh post-check-p3   # Verify after Phase 3 (standards reorg)
#   ./validate_reorg.sh post-check-p5   # Verify after Phase 5 (cleanup)
#   ./validate_reorg.sh deliverables    # Check for manifest/doc deliverables
#   ./validate_reorg.sh all             # Run all post-migration checks

# --- Configuration ---
PROJECT_ROOT=$(dirname "$(dirname "$0")")
cd "$PROJECT_ROOT" || exit 1

# Color Codes
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Counters
PASS_COUNT=0
FAIL_COUNT=0

# --- Helper Functions ---
_check() {
    local condition=$1
    local message=$2
    if eval "$condition"; then
        echo -e "${GREEN}PASS:${NC} $message"
        ((PASS_COUNT++))
    else
        echo -e "${RED}FAIL:${NC} $message"
        ((FAIL_COUNT++))
    fi
}

check_file_exists() { _check "[ -f \"$1\" ]" "File exists: $1"; }
check_dir_exists() { _check "[ -d \"$1\" ]" "Directory exists: $1"; }
check_dir_does_not_exist() { _check "[ ! -d \"$1\" ]" "Directory removed: $1"; }
check_symlink_exists() { _check "[ -L \"$1\" ]" "Symlink exists: $1"; }
check_symlink_removed() { _check "[ ! -L \"$1\" ]" "Symlink removed: $1"; }
check_script_runs() { _check "python3 \"$1\"" "Script runs successfully: $1"; }

# --- Check Functions ---

# Checks the state *before* any migration starts
check_pre_migration_state() {
    echo -e "\n${YELLOW}--- Verifying Pre-Migration State ---${NC}"
    check_dir_exists "change_management"
    check_dir_exists "archive"
    check_dir_exists "drafts"
    check_dir_exists "exports"
    check_dir_exists "templates"
    check_dir_exists "control-standards/drafts"
    check_dir_exists "control-standards/design_drafts"
    check_symlink_exists "rag"
    check_dir_exists "control-standards/rag/standards_intelligence/nec"
    check_dir_exists "control-standards/rag/standards_intelligence/_overlap_matrix"
}

# Checks for the existence of manifest and checksum files
check_deliverables() {
    echo -e "\n${YELLOW}--- Verifying Plan Deliverables ---${NC}"
    check_file_exists "planning/manifests/pre_move_manifest.txt"
    check_file_exists "planning/manifests/pre_move_checksums.txt"
    check_file_exists "planning/manifests/pre_move_git_status.txt"
    
    # These might not exist until the end
    if [ -f "planning/manifests/post_move_manifest.txt" ]; then
        check_file_exists "planning/manifests/post_move_manifest.txt"
        check_file_exists "planning/manifests/post_move_checksums.txt"
    else
        echo -e "${YELLOW}INFO:${NC} Post-move manifests not yet created."
    fi

    check_file_exists "README.md"
}

# Checks after Phase 2: Folder Consolidation
check_post_phase2() {
    echo -e "\n${YELLOW}--- Verifying Post-Phase 2: Consolidation ---${NC}"
    # Old root folders should be gone
    check_dir_does_not_exist "change_management"
    check_dir_does_not_exist "archive"
    check_dir_does_not_exist "drafts"
    check_dir_does_not_exist "exports"
    check_dir_does_not_exist "templates"

    # New consolidated folders should exist
    check_dir_exists "control-standards/governance"
    check_dir_exists "control-standards/archive"
    check_dir_exists "control-standards/exports"
    check_dir_exists "control-standards/templates"
    check_dir_exists "control-standards/work/general"
    check_dir_exists "control-standards/work/design"
    check_dir_exists "control-standards/restricted/legacy_drafts"
    check_dir_exists "control-standards/restricted/do_not_read"
}

# Checks after Phase 3: Standards Reorganization
check_post_phase3() {
    echo -e "\n${YELLOW}--- Verifying Post-Phase 3: Standards Reorg ---${NC}"
    local SI_PATH="control-standards/rag/standards_intelligence"
    # New structure
    check_dir_exists "$SI_PATH/us/nec"
    check_dir_exists "$SI_PATH/us/nfpa79"
    check_dir_exists "$SI_PATH/international/machinery/iec_60204_1"
    check_dir_exists "$SI_PATH/international/functional_safety"
    check_dir_exists "$SI_PATH/crosswalks"

    # Old structure should be gone
    check_dir_does_not_exist "$SI_PATH/nec"
    check_dir_does_not_exist "$SI_PATH/_overlap_matrix"
}

# --- Main Execution ---
main() {
    case "$1" in
        pre-check) check_pre_migration_state ;;
        post-check-p2) check_post_phase2 ;;
        post-check-p3) check_post_phase3 ;;
        deliverables) check_deliverables ;;
        all)
            echo -e "\n${YELLOW}--- Running ALL Post-Migration Checks ---${NC}"
            check_deliverables
            check_post_phase2
            check_post_phase3
            echo -e "\n${YELLOW}--- Running Supporting Scripts ---${NC}"
            check_script_runs "tools/project_automator.py"
            check_script_runs "tools/validate_ai_boundaries.py"
            ;;
        *)
            echo "Usage: $0 {pre-check|post-check-p2|post-check-p3|deliverables|all}"
            exit 1
            ;;
    esac

    echo -e "\n${YELLOW}--- Summary ---${NC}"
    echo -e "Total Checks: $((PASS_COUNT + FAIL_COUNT))"
    echo -e "${GREEN}Passed: $PASS_COUNT${NC}"
    echo -e "${RED}Failed: $FAIL_COUNT${NC}"

    if [ "$FAIL_COUNT" -gt 0 ]; then exit 1; else exit 0; fi
}

main "$@"
# Tools

**AI_READ_ACCESS: ALLOWED (for understanding automation)**

Optional local scripts for offline automation and validation.

## Contents

### Validation Scripts

- **validate_ai_boundaries.py**: Enforces AI safety rules in `/rag/`
  - **Usage:** `python3 tools/validate_ai_boundaries.py`
  - **Checks:**
    1. Presence of `AI_READ_ACCESS: ALLOWED` tag in all Markdown files.
    2. Absence of forbidden keywords (CONFIDENTIAL, INTERNAL ONLY).
  - **Exit Code:** Returns 1 on violation (suitable for CI/CD or Git Hooks).

- **fix_ai_boundaries.py**: Automatically fixes common AI safety violations
  - **Usage:** `python3 tools/fix_ai_boundaries.py`
  - **Function:** Adds missing `AI_READ_ACCESS: ALLOWED` headers and replaces forbidden "NO-AI" keywords with "AI-FORBIDDEN".

### Automation Scripts

- **project_automator.py**: Self-updating documentation agent
  - **Usage:** `python3 tools/project_automator.py` (or via Git Hook)
  - **Function:** Scans project structure to update `STRUCTURE_SUMMARY.md` and aggregates logs into `general_change_log.md`.

- **generate_rag_index.py**: Automated librarian
  - **Usage:** `python3 tools/generate_rag_index.py`
  - **Function:** Crawls `/rag/` directories and builds `_index.yaml` files mapping filenames to titles.
  - **Safety:** Will NOT overwrite `_index.yaml` files that were manually created (checks for auto-gen header).

### Generation Scripts

- **generate_report.sh** / **.ps1**: Template for report generation scripts
  - Reads from /rag/
  - Generates outputs to /exports/
  - Can be customized per tool/module

## Script Development Guidelines

- Scripts should be cross-platform where possible (both .sh and .ps1 versions)
- Always read from /rag/ only (never /drafts/)
- Log all generation actions
- Validate inputs before processing
